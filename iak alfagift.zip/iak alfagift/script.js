const slider = document.querySelector('.slides');
const slides = document.querySelectorAll('.slide');
let currentIndex = 0;

function moveSlider() {
    currentIndex++;
    if (currentIndex >= slides.length) {
        currentIndex = 0; // Reset to the first slide if we reach the end
    }
    slider.style.transform = `translateX(-${currentIndex * slides[currentIndex].offsetWidth}px)`; // Menggeser sesuai ukuran slide
}

// Move the slider automatically every 3 seconds
setInterval(moveSlider, 3000);


function showErrorModal(message) {
    document.getElementById("error-message").innerText = message;
    document.getElementById("errorModal").style.display = "block";
}

function closeModal() {
    document.getElementById("errorModal").style.display = "none";
    window.location.href = "signin.php";  // Redirect ke halaman login setelah menutup modal
}