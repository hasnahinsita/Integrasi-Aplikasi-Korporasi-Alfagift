<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    // Enkripsi password menggunakan MD5
    $hashed_password = md5($password);

    // Koneksi ke database
    $conn = new mysqli('localhost', 'root', '', 'alfagift');

    // Periksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Periksa apakah email sudah terdaftar
    $check_email_sql = "SELECT email FROM users WHERE email = ?";
    $stmt = $conn->prepare($check_email_sql);
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // Email sudah terdaftar
        echo "<script>
                alert('Email sudah terdaftar. Gunakan email lain.');
                window.location.href = 'signup.php';
              </script>";
    } else {
        // Simpan data pengguna baru
        $insert_sql = "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'user')";
        $stmt = $conn->prepare($insert_sql);
        $stmt->bind_param('sss', $username, $email, $hashed_password);

        if ($stmt->execute()) {
            // Pendaftaran berhasil
            echo "<script>
                    alert('Pendaftaran berhasil! Silakan login.');
                    window.location.href = 'sign in.php';
                  </script>";
        } else {
            // Gagal menyimpan data
            echo "<script>
                    alert('Pendaftaran gagal. Silakan coba lagi.');
                    window.location.href = 'signup.php';
                  </script>";
        }
    }

    $stmt->close();
    $conn->close();
}
?>





<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Alfagift</title>
    <link rel="stylesheet" href="signup.css">
</head>

<body>
    <!-- Header -->
    <header>
        <div class="top-bar">
            <div class="social-media">
                <a href="#" class='fb'><img src="faceb.png" alt="Facebook"></a>
                <a href="#"><img src="twit.png" alt="Twitter"></a>
                <a href="#"><img src="youtube.png" alt="YouTube"></a>
                <a href="#"><img src="instag.png" alt="Instagram"></a>
            </div>
            <div class="language">
                <span>Order tracking</span>
                <span>Help</span>
                <div class="dropdown">
                    <img src="US.png" alt="US Flag" class="flag">
                    <select class='bhs'>
                        <option>English (US)</option>
                        <option>Indonesia</option>
                    </select>
                </div>
            </div>

        </div>
        <div class="main-header">
            <img src="alfagift.png" alt="Alfagift Logo" class="logo">
            <div class="search-bar">

                <input type="text" placeholder="Search something...">
                <select>
                    <option class='opsi'>All Categories</option>
                </select>
                <button class='search'><img src="Search.png" alt="Search Icon"></button>

            </div>
            <nav>
                <a href="#" class='cart'><img src="cart.png" alt="Cart"><span class="badge">3</span></a>
                <a href="#" class='cart'><img src="love.png" alt="Wishlist"></a>
                <a href="#" class="account-section">
                    <img src="account.png" alt="Account" class='account'>
                    <div>
                        <span class="join-text">Join Alfagift</span>
                        <span class="account-text">My Account</span>
                    </div>
                </a>
            </nav>

        </div>
    </header>
    <div class="container">
    <div class="form-container">
        <!-- Form Sign Up -->
        <h2>Sign Up</h2>
        <form method="POST" action="">
            <label for="username">Username</label>
            <input type="text" name="username" id="username" required>
            <label for="email">Email</label>
            <input type="email" name="email" id="email" required>
            <label for="password">Password</label>
            <input type="password" name="password" id="password" required>
            <button type="submit" class="sign-up-btn">Sign Up</button>
        </form>
        <p>Sudah punya akun? <a href="sign in.php">Login di sini</a>.</p>
       
    </div>
    <div class="slider-container">
        <!-- Slider -->
        <div class="slides">
            <div class="slide">
                <img src="alfa1.png" alt="Slide 1">
                <div class="slide-text">
                    <h5>Crazy deals 7.7.7</h5>
                    <p>Free Shipping All!</p>
                    <p>Register now and subscribe to our newsletter to get 25% discount.</p>
                </div>
            </div>
            <div class="slide">
                <img src="alfa3.png" alt="Slide 2">
                <div class="slide-text">
                    <h5>Amazing Offers</h5>
                    <p>Discounts up to 50%!</p>
                    <p>Shop now and save big on your favorite items.</p>
                </div>
            </div>
        </div>
    </div>
</div>
    <script src="script.js"></script>
    <script>
        document.getElementById('sign-up-form').addEventListener('submit', function (e) {
            e.preventDefault(); // Mencegah pengiriman form default

            // Ambil data dari form
            const formData = new FormData(this);
            const messageElement = document.getElementById('message');

            // Kirim data ke server menggunakan Fetch API
            fetch('sign_up.php', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'error') {
                    // Tampilkan pesan kesalahan
                    messageElement.style.display = 'block';
                    messageElement.textContent = data.message;
                } else if (data.status === 'success') {
                    // Alihkan ke halaman sign-in
                    window.location.href = 'sign_in.php';
                }
            })
            .catch(error => {
                console.error('Terjadi kesalahan:', error);
            });
        });
    </script>
    <footer>
        <div class="footer-container">
            <div class="logo-section">
                <img src="alfagift.png" alt="Logo" class="logo">
            </div>
            <div class="menu-section">
                <div class="menu-column">
                    <h4>First Menu</h4>
                    <ul>
                        <li>Features</li>
                        <li>Enterprise</li>
                        <li>Security</li>
                        <li>Customer Stories</li>
                        <li>Pricing</li>
                        <li>Demo</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Second Menu</h4>
                    <ul>
                        <li>Engineering</li>
                        <li>Financial Services</li>
                        <li>Sales</li>
                        <li>IT</li>
                        <li>Customer Support</li>
                        <li>Human Resources</li>
                        <li>Media</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Third Menu</h4>
                    <ul>
                        <li>Tips</li>
                        <li>Blog</li>
                        <li>Event</li>
                        <li>Certified Program</li>
                        <li>Help Center</li>
                        <li>API</li>
                        <li>Download Template</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Fourth Menu</h4>
                    <ul>
                        <li>About Us</li>
                        <li>Leadership</li>
                        <li>News</li>
                        <li>Media Kit</li>
                        <li>Career</li>
                        <li>Documentation</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Alfagift © Copyright 2020, Inc. All rights reserved</p>
            <div class="social-media">
                <span>FB</span>
                <span>TW</span>
                <span>LN</span>
                <span>IG</span>
                <span>GH</span>
            </div>
        </div>
    </footer>
</body>

</html>