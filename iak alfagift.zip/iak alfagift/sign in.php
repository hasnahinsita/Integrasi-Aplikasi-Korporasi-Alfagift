<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username_or_email = trim($_POST['username_or_email']);
    $password = md5(trim($_POST['password']));  // Sebaiknya menggunakan password_hash untuk keamanan

    // Koneksi ke database
    $conn = new mysqli('localhost', 'root', '', 'alfagift');

    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Periksa apakah email/username ada di database
    $sql = "SELECT * FROM users WHERE username = ? OR email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $username_or_email, $username_or_email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Periksa password
        if ($user['password'] === $password) {
            // Menyimpan data pengguna dalam sesi
            $_SESSION['user'] = $user;
            $_SESSION['user_id'] = $user['id'];  // Menyimpan ID pengguna dalam sesi

            // Return success response
            echo json_encode(['success' => true]);
            exit();
        } else {
            // Return error message for wrong password
            echo json_encode(['success' => false, 'message' => 'Password salah. Silakan coba lagi.']);
            exit();
        }
    } else {
        // Return error message if email/username not found
        echo json_encode(['success' => false, 'message' => 'Email atau username tidak ditemukan.']);
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>






<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In - Alfagift</title>
    <link rel="stylesheet" href="signi n.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <!-- Header -->
    <header>
        <div class="top-bar">
            <div class="social-media">
                <a href="#" class='fb'><img src="faceb.png" alt="Facebook"></a>
                <a href="#"><img src="twit.png" alt="Twitter"></a>
                <a href="#"><img src="youtube.png" alt="YouTube"></a>
                <a href="#"><img src="instag.png" alt="Instagram"></a>
            </div>
            <div class="language">
                <span>Order tracking</span>
                <span>Help</span>
                <div class="dropdown">
                    <img src="US.png" alt="US Flag" class="flag">
                    <select class='bhs'>
                        <option>English (US)</option>
                        <option>Indonesia</option>
                    </select>
                </div>
            </div>

        </div>
        <div class="main-header">

            <img src="alfagift.png" alt="Alfagift Logo" class="logo">
            <div class="search-bar">

                <input type="text" placeholder="Search something...">
                <select>
                    <option class='opsi'>All Categories</option>
                </select>
                <button class='search'><img src="Search.png" alt="Search Icon"></button>

            </div>
            <nav>
                <a href="#" class='cart'><img src="cart.png" alt="Cart"></a>
                <a href="#" class='cart'><img src="love.png" alt="Wishlist"></a>
                <a href="#" class="account-section">
                    <img src="account.png" alt="Account" class='account'>
                    <div>
                        <span class="join-text">Join Alfagift</span>
                        <span class="account-text">My Account</span>
                    </div>
                </a>
            </nav>

        </div>
    </header>

    <div class="container">
        <!-- Sign In Form Section -->
        <div class="form-container">
            <div class="header">
                <h2>Sign in to Alfagift</h2>
                <a href="signup.php" class="register-link">Register here ></a>
            </div>
            <div class="login-options">
                <button class="google-login">
                    <img src="Google.png" alt="Google Icon">
                    Register with Google
                </button>
                <div class="social-login">
                    <button class="social-btn">
                        <img src="twit.png" alt="Twitter">
                    </button>
                    <button class="social-btn">
                        <img src="faceb.png" alt="Facebook">
                    </button>
                </div>
            </div>

            <form id="loginForm">
                <label for="username">Username or Email</label>
                <input type="text" id="username" name="username_or_email" required>
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                <button type="submit" class="sign-in-btn">Sign In</button>
            </form>
        </div>
   

    <!-- Slider Section -->
    <div class="slider-container">
        <div class="slides">
            <div class="slide">
                <img src="alfa1.png" alt="Slide 1">
                <div class="slide-text">
                    <h5>Crazy deals 7.7.7</h5>
                    <p>Free Shipping All!</p>
                    <p>Register now and subscribe our Newsletter to get and claim the 25% discount.</p>
                </div>
            </div>
            <div class="slide">
                <img src="alfa3.png" alt="Slide 2">
                <div class="slide-text">
                    <h5>Amazing Offers</h5>
                    <p>Discounts up to 50%!</p>
                    <p>Shop now and save big on your favorite items.</p>
                </div>
            </div>
            <div class="slide">
                <img src="alfa1.png" alt="Slide 3">
                <div class="slide-text">
                    <h5>Exclusive Products</h5>
                    <p>Just for You!</p>
                    <p>Sign up and explore our exclusive deals and offers.</p>
                </div>
            </div>
        </div>
    </div>
    </div>

    <script src="script.js"></script>
    <script>
        $('#loginForm').on('submit', function(e) {
            e.preventDefault();

            var formData = $(this).serialize(); // Serialize form data

            $.ajax({
                type: 'POST',
                url: 'sign in.php', // The PHP script to handle login
                data: formData,
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        // Redirect to home.php if login is successful
                        window.location.href = 'user/homelogin.php';
                    } else {
                        // Display error message in pop-up
                        alert(response.message); // Show the error message in a pop-up
                    }
                },
                error: function() {
                    alert('Something went wrong. Please try again.');
                }
            });
        });
    </script>

    <footer>
        <div class="footer-container">
            <div class="logo-section">
                <img src="alfagift.png" alt="Logo" class="logo">
            </div>
            <div class="menu-section">
                <div class="menu-column">
                    <h4>First Menu</h4>
                    <ul>
                        <li>Features</li>
                        <li>Enterprise</li>
                        <li>Security</li>
                        <li>Customer Stories</li>
                        <li>Pricing</li>
                        <li>Demo</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Second Menu</h4>
                    <ul>
                        <li>Engineering</li>
                        <li>Financial Services</li>
                        <li>Sales</li>
                        <li>IT</li>
                        <li>Customer Support</li>
                        <li>Human Resources</li>
                        <li>Media</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Third Menu</h4>
                    <ul>
                        <li>Tips</li>
                        <li>Blog</li>
                        <li>Event</li>
                        <li>Certified Program</li>
                        <li>Help Center</li>
                        <li>API</li>
                        <li>Download Template</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Fourth Menu</h4>
                    <ul>
                        <li>About Us</li>
                        <li>Leadership</li>
                        <li>News</li>
                        <li>Media Kit</li>
                        <li>Career</li>
                        <li>Documentation</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Alfagift © Copyright 2020, Inc. All rights reserved</p>
            <div class="social-media">
                <span>FB</span>
                <span>TW</span>
                <span>LN</span>
                <span>IG</span>
                <span>GH</span>
            </div>
        </div>
    </footer>
</body>

</html>