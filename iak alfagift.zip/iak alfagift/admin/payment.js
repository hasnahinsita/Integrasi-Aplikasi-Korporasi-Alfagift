function loadPage(page) {
    // Hapus menu aktif sebelumnya
    const menuItems = document.querySelectorAll('.menu li');
    menuItems.forEach((item) => item.classList.remove('active'));

    // Tambahkan menu aktif ke menu yang dipilih
    const selectedMenu = document.querySelector(`a[href="#${page}"]`).parentElement;
    selectedMenu.classList.add('active');

    const content = document.getElementById("content");
    let htmlContent = "";

    if (page === "dashboard") {
        htmlContent = `
            <div class="dashboard">
                <div class="stats">
                    <div class="stat-card">
                        <h3>Total Penjualan</h3>
                        <p>Rp 120.000.000</p>
                    </div>
                    <div class="stat-card">
                        <h3>Pesanan Aktif</h3>
                        <p>45 Pesanan</p>
                    </div>
                    <div class="stat-card">
                        <h3>Promo Aktif</h3>
                        <p>10 Promo</p>
                    </div>
                </div>
                <div class="notifications">
                    <h3>Notifikasi</h3>
                    <ul>
                        <li>Pesanan #1023 telah dikirim</li>
                        <li>Pembayaran #2044 menunggu verifikasi</li>
                        <li>Promo "Diskon Akhir Tahun" berhasil dibuat</li>
                    </ul>
                </div>
            </div>
        `;
    } else {
        htmlContent = `<p>Halaman belum tersedia.</p>`;
    }

    content.innerHTML = htmlContent;
}

document.querySelectorAll('.menu li a').forEach(link => {
    link.addEventListener('mouseenter', function() {
        // Membesarkan ikon dan teks saat kursor masuk
        this.querySelector('i').style.fontSize = '20px'; // Ukuran ikon membesar
        this.style.transform = 'scale(1.1)'; // Seluruh link membesar
        this.style.fontSize = '15px'; // Ukuran teks membesar
    });

    link.addEventListener('mouseleave', function() {
        // Kembali ke ukuran semula saat kursor keluar
        this.querySelector('i').style.fontSize = '20px'; // Ukuran ikon normal
        this.style.transform = 'scale(1)'; // Ukuran link normal
        this.style.fontSize = '13px'; // Ukuran teks normal
    });
});
function fetchStoreData(store) {
    fetch('fetch_data.php?store=' + store)
        .then(response => response.json())
        .then(data => {
            // Update the dashboard with fetched data
            updateDashboard(data);
        })
        .catch(error => console.error('Error:', error));
}

function updateDashboard(data) {
    // Replace dashboard content dynamically
    document.querySelector('.stats-container').innerHTML = `
        <div class="stats-row">
            <div class="stats-card">
                <h3>Pesanan Aktif</h3>
                <p>${data.active_orders} Pesanan</p>
            </div>
            <div class="stats-card">
                <h3>Promo Aktif</h3>
                <p>${data.active_promos} Promo</p>
            </div>
        </div>
        <div class="stats-card stats-bottom">
            <h3>Total Penjualan</h3>
            <p>Rp ${data.total_sales}</p>
        </div>
    `;
}
function showEditPaymentModal(id, storeId, userId, orderId, paymentMethod, amount, status) {
    document.getElementById("edit-id").value = id;
    document.getElementById("edit-store-id").value = storeId;
    document.getElementById("edit-user-id").value = userId;
    document.getElementById("edit-order-id").value = orderId;
    document.getElementById("edit-payment-method").value = paymentMethod;
    document.getElementById("edit-amount").value = amount;
    document.getElementById("edit-status").value = status;

    const modal = document.getElementById("editModal");
    modal.style.display = "block";
}

function closeEditPaymentModal() {
    const modal = document.getElementById("editModal");
    modal.style.display = "none";
}

function deletePayment(id) {
    if (confirm("Apakah Anda yakin ingin menghapus pembayaran ini?")) {
        fetch(`delete_payment.php?id=${id}`, { method: "DELETE" })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById(`payment-${id}`).remove();
                    alert("Pembayaran berhasil dihapus.");
                } else {
                    alert("Gagal menghapus pembayaran: " + data.error);
                }
            })
            .catch(error => {
                console.error("Error:", error);
            });
    }
}

document.getElementById("store_id")?.addEventListener("change", function () {
    document.getElementById("storeForm").submit();
});

// JavaScript END