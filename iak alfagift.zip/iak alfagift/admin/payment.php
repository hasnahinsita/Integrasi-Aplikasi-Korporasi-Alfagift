<?php
$mysqli = new mysqli("localhost", "root", "", "alfagift");

if ($mysqli->connect_error) {
    echo json_encode(['success' => false, 'error' => $mysqli->connect_error]);
    exit;
}

// Ambil data pembayaran dari tabel
$query_payments = "SELECT p.id, p.store_id, p.user_id, p.order_id, p.payment_method, p.amount, p.status, p.created_at, o.first_name, o.last_name, s.name AS store_name
                   FROM payments p
                   JOIN orders o ON p.order_id = o.id
                   JOIN stores s ON p.store_id = s.id";

$result_payments = $mysqli->query($query_payments);

if (!$result_payments) {
    die("Error: " . $mysqli->error);
}

// Ambil data pembayaran dalam bentuk array
$payments = $result_payments->fetch_all(MYSQLI_ASSOC);
// Cek apakah ada permintaan untuk mengubah status

// Cek apakah ada permintaan untuk mengubah status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['payment_id']) && isset($_POST['status'])) {
    $payment_id = $_POST['payment_id'];
    $status = $_POST['status'];

    // Update status pembayaran
    $query_update = $mysqli->prepare("UPDATE payments SET status = ? WHERE id = ?");
    $query_update->bind_param("si", $status, $payment_id);

    if ($query_update->execute()) {
        // Setelah update, arahkan kembali ke halaman pembayaran untuk menampilkan status terbaru
        header("Location: payment.php");
        exit;
    } else {
        echo json_encode(['success' => false, 'error' => $mysqli->error]);
    }
}



// Ambil daftar toko untuk dropdown
$query = "SELECT id, name FROM stores";
$result = $mysqli->query($query);
if (!$result) {
    die("Error: " . $mysqli->error);
}

// Cek apakah ada toko yang dipilih
$store_id = isset($_GET['store_id']) ? $_GET['store_id'] : '';

// Query untuk mengambil data produk berdasarkan toko yang dipilih
if ($store_id) {
    $query = $mysqli->prepare("SELECT * FROM products WHERE store_id = ?");
    $query->bind_param("i", $store_id);
} else {
    $query = $mysqli->prepare("SELECT * FROM products");
}

$query->execute();
$result_products = $query->get_result();
$products = $result_products->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alfagift Admin Panel</title>
    <link rel="stylesheet" href="itemcart.css">
    <script src="itemcart.js" defer></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

</head>

<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="warna">
            <aside class="sidebar">
                <div class="sidebar-header">
                    <img src="alfagiftt.png" alt="Logo Alfagift" class="logo">
                </div>
                <ul class="menu">

                    <li>
                        <a href="dasboard.php">
                            <i class="fas fa-home"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>

                    <li class="oki">
                        <a href="produk.php">
                            <i class="fas fa-box"></i>
                            <span>Produk & Stok</span>
                        </a>
                    </li>
                    <div class="ak">
                        <li class="active">
                            <a href="payment.php">
                                <i class="fas fa-credit-card"></i>
                                <span>Verifikasi Pembayaran</span>
                            </a>
                        </li>
                    </div>
                    <li class="okey">
                        <a href="promo.php">
                            <i class="fas fa-tags"></i>
                            <span>Paket Promo</span>
                        </a>
                    </li>

                    <li>

                        <a href="itemcar.php">
                            <i class="fas fa-clipboard-list"></i>
                            <span>Order Items</span>
                        </a>
                    </li>

                    <li>
                    <a href="orders.php">
    <i class="fas fa-list-alt"></i>
    <span>Orders</span>
</a>

                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                </ul>
            </aside>
        </div>

        <!-- Main Content -->
        <main class="main-content">
            <header class="header">
                <h1>Payment</h1>
                <form method="GET" id="storeForm">
                    <label for="store_id">Pilih Toko:</label>
                    <select name="store_id" id="store_id" onchange="this.form.submit()">
                        <option value="">-- Pilih Toko --</option>
                        <?php
                        // Tampilkan pilihan toko dalam dropdown
                        while ($row = mysqli_fetch_assoc($result)) {
                            // Mengecek jika store_id sudah dipilih sebelumnya, maka memberi atribut 'selected'
                            $selected = (isset($_GET['store_id']) && $_GET['store_id'] == $row['id']) ? 'selected' : '';
                            echo "<option value='" . $row['id'] . "' $selected>" . $row['name'] . "</option>";
                        }
                        ?>
                    </select>
                </form>
            </header>
            <table class="product-table">
                <thead>
                    <tr>
                        <th>ID Pembayaran</th>
                        <th>Toko</th>
                        <th>Nama Pembeli</th>
                        <th>Metode Pembayaran</th>
                        <th>Jumlah</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($payments)): ?>
                        <?php foreach ($payments as $payment): ?>
                            <tr>
                                <td><?= $payment['id'] ?></td>
                                <td><?= $payment['store_name'] ?></td>
                                <td><?= $payment['first_name'] ?> <?= $payment['last_name'] ?></td>
                                <td><?= $payment['payment_method'] ?></td>
                                <td><?= number_format($payment['amount'], 2) ?></td>
                                <td>
                                    <?= $payment['status'] ?>
                                </td>
                                <td>
                                    <!-- Form untuk mengubah status -->
                                    <form method="POST">
                                        <input type="hidden" name="payment_id" value="<?= $payment['id'] ?>">
                                        <select name="status">
                                            <option value="pending" <?= $payment['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                                            <option value="completed" <?= $payment['status'] == 'completed' ? 'selected' : '' ?>>Completed</option>
                                            <option value="failed" <?= $payment['status'] == 'failed' ? 'selected' : '' ?>>Failed</option>
                                        </select>
                                        <button type="submit">Update Status</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align:center;">Tidak ada data pembayaran</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

    </div>


    </main>
    </div>
    <script>
        // Tangkap form update status pembayaran
        document.querySelectorAll('form').forEach(form => {
            form.addEventListener('submit', function(event) {
                event.preventDefault();

                const formData = new FormData(form);

                // Kirim data menggunakan AJAX
                fetch('payment.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Perbarui status di tabel tanpa me-refresh halaman
                            const statusCell = form.closest('tr').querySelector('td:nth-child(6)');
                            const selectedStatus = form.querySelector('select').value;
                            statusCell.textContent = selectedStatus; // Update status di kolom tabel

                            alert(data.message); // Tampilkan pesan sukses
                        } else {
                            alert('Error: ' + data.error);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            });
        });
    </script>
</body>

</html>