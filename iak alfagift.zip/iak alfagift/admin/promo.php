<?php
$mysqli = new mysqli("localhost", "root", "", "alfagift");

if ($mysqli->connect_error) {
    echo json_encode(['success' => false, 'error' => $mysqli->connect_error]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $store_id = $_POST['store_id'];

    $image_path = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        // Validasi ukuran file
        $maxFileSize = 5 * 1024 * 1024; // 5MB

        if ($_FILES['image']['size'] > $maxFileSize) {
            echo json_encode([
                'success' => false,
                'error' => 'Ukuran file terlalu besar. Maksimum adalah 5MB.'
            ]);
            exit;
        }

        $image_name = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_path = "uploads/" . basename($image_name);

        if (!move_uploaded_file($image_tmp, $image_path)) {
            echo json_encode(['success' => false, 'error' => 'Gagal mengunggah gambar.']);
            exit;
        }
    }

    $query = $mysqli->prepare("INSERT INTO promotions (title, description, image_path, store_id) VALUES (?, ?, ?, ?)");
    $query->bind_param("sssi", $title, $description, $image_path, $store_id);

    if ($query->execute()) {
        echo json_encode([
            'success' => true,
            'data' => [
                'id' => $query->insert_id,
                'title' => $title,
                'description' => $description,
                'image_path' => $image_path
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => $mysqli->error]);
    }
}

/// Ambil daftar toko untuk dropdown
$query = "SELECT id, name FROM stores";
$result = $mysqli->query($query);
if (!$result) {
    die("Error: " . $mysqli->error);
}

// Cek apakah ada toko yang dipilih (dari query string)
$store_id = isset($_GET['store_id']) ? $_GET['store_id'] : '';

// Query untuk mengambil data promosi berdasarkan toko yang dipilih
if ($store_id) {
    // Jika ada toko yang dipilih, tampilkan promosi untuk toko tersebut
    $query = $mysqli->prepare("SELECT * FROM promotions WHERE store_id = ?");
    $query->bind_param("i", $store_id);
} else {
    // Jika tidak ada toko yang dipilih, tampilkan semua promosi
    $query = $mysqli->prepare("SELECT * FROM promotions");
}

$query->execute();
$result_promotions = $query->get_result();
$promotions = $result_promotions->fetch_all(MYSQLI_ASSOC);



?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alfagift Admin Panel</title>
    <link rel="stylesheet" href="promo.css">
    <script src="promo.js" defer></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

</head>

<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="warna">
            <aside class="sidebar">
                <div class="sidebar-header">
                    <img src="alfagiftt.png" alt="Logo Alfagift" class="logo">
                </div>
                <ul class="menu">

                    <li>
                        <a href="dasboard.php">
                            <i class="fas fa-home"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>

                    <li>
                        <a href="produk.php">
                            <i class="fas fa-box"></i>
                            <span>Produk & Stok</span>
                        </a>
                    </li>
                    <li class="oki">
                        <a href="payment.php">
                            <i class="fas fa-credit-card"></i>
                            <span>Verifikasi Pembayaran</span>
                        </a>
                    </li>
                    <div class="ak">
                        <li class="active">
                            <a href="promo.php">
                                <i class="fas fa-tags"></i>
                                <span>Paket Promo</span>
                            </a>
                        </li>
                    </div>
                    <li class="okey">
                    <a href="itemcar.php">
                                <i class="fas fa-clipboard-list"></i>
                                <span>Order Items</span>
                            </a>
                    </li>
                    <li>
                    <li>
                    <a href="orders.php">
    <i class="fas fa-list-alt"></i>
    <span>Orders</span>
</a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                </ul>
            </aside>
        </div>

        <!-- Main Content -->
        <main class="main-content">
            <header class="header">
                <h1>Promotion</h1>
                <form method="GET" id="storeForm">
                    <label for="store_id">Pilih Toko:</label>
                    <select name="store_id" id="store_id" onchange="this.form.submit()">
                        <option value="">-- Pilih Toko --</option>
                        <?php
                        // Tampilkan pilihan toko dalam dropdown
                        while ($row = mysqli_fetch_assoc($result)) {
                            // Mengecek jika store_id sudah dipilih sebelumnya, maka memberi atribut 'selected'
                            $selected = (isset($_GET['store_id']) && $_GET['store_id'] == $row['id']) ? 'selected' : '';
                            echo "<option value='" . $row['id'] . "' $selected>" . $row['name'] . "</option>";
                        }
                        ?>
                    </select>
                </form>
            </header>



            <div class="promotion-list">

                <table class="promotion-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Judul</th>
                            <th>Deskripsi</th>
                            <th>Gambar</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="promotion-list">
                        <?php foreach ($promotions as $promo): ?>
                            <tr id="promo-<?= $promo['id'] ?>">
                                <td><?= $promo['id'] ?></td>
                                <td><?= $promo['title'] ?></td>
                                <td><?= $promo['description'] ?></td>
                                <td><img src="<?= $promo['image_path'] ?>" alt="Promo Image"></td>
                                <td class="action-icons">
                                    <i class="fas fa-edit" onclick="showEditModal(<?= $promo['id'] ?>, '<?= $promo['title'] ?>', '<?= $promo['description'] ?>', '<?= $promo['image_path'] ?>')"></i>
                                    <i class="fas fa-trash" onclick="deletePromotion(<?= $promo['id'] ?>)"></i>
                                </td>

                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

            </div>
            <div class="form-container">
                <form id="promo-form" method="POST" enctype="multipart/form-data" action="add_promotion.php">

                    <input type="text" name="title" placeholder="Judul Promo" required>
                    <textarea name="description" placeholder="Deskripsi" required></textarea>
                    <input type="file" name="image" accept="image/*" required>
                    <!-- Hidden field for store_id -->
                    <input type="hidden" name="store_id" value="<?= htmlspecialchars($store_id) ?>">
                    <button type="submit">Tambah Promosi</button>
                </form>
            </div>




        </main>
    </div>
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEditModal()">&times;</span>
            <h2>Edit Promosi</h2>
            <form id="edit-form" method="POST" enctype="multipart/form-data" action="edit_promotion.php">
                <input type="hidden" name="id" id="edit-id">
                <input type="text" name="title" id="edit-title" placeholder="Judul Promo" required>
                <textarea name="description" id="edit-description" placeholder="Deskripsi" required></textarea>
                <input type="file" name="image" accept="image/*">
                <input type="hidden" name="store_id" value="<?= htmlspecialchars($store_id) ?>">
                <button type="submit">Simpan Perubahan</button>
            </form>
        </div>
    </div>


</body>

</html>