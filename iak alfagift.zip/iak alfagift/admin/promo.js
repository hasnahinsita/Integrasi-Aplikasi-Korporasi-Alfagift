function loadPage(page) {
    // Hapus menu aktif sebelumnya
    const menuItems = document.querySelectorAll('.menu li');
    menuItems.forEach((item) => item.classList.remove('active'));

    // Tambahkan menu aktif ke menu yang dipilih
    const selectedMenu = document.querySelector(`a[href="#${page}"]`).parentElement;
    selectedMenu.classList.add('active');

    const content = document.getElementById("content");
    let htmlContent = "";

    if (page === "dashboard") {
        htmlContent = `
            <div class="dashboard">
                <div class="stats">
                    <div class="stat-card">
                        <h3>Total Penjualan</h3>
                        <p>Rp 120.000.000</p>
                    </div>
                    <div class="stat-card">
                        <h3>Pesanan Aktif</h3>
                        <p>45 Pesanan</p>
                    </div>
                    <div class="stat-card">
                        <h3>Promo Aktif</h3>
                        <p>10 Promo</p>
                    </div>
                </div>
                <div class="notifications">
                    <h3>Notifikasi</h3>
                    <ul>
                        <li>Pesanan #1023 telah dikirim</li>
                        <li>Pembayaran #2044 menunggu verifikasi</li>
                        <li>Promo "Diskon Akhir Tahun" berhasil dibuat</li>
                    </ul>
                </div>
            </div>
        `;
    } else {
        htmlContent = `<p>Halaman belum tersedia.</p>`;
    }

    content.innerHTML = htmlContent;
}

document.querySelectorAll('.menu li a').forEach(link => {
    link.addEventListener('mouseenter', function() {
        // Membesarkan ikon dan teks saat kursor masuk
        this.querySelector('i').style.fontSize = '20px'; // Ukuran ikon membesar
        this.style.transform = 'scale(1.1)'; // Seluruh link membesar
        this.style.fontSize = '15px'; // Ukuran teks membesar
    });

    link.addEventListener('mouseleave', function() {
        // Kembali ke ukuran semula saat kursor keluar
        this.querySelector('i').style.fontSize = '20px'; // Ukuran ikon normal
        this.style.transform = 'scale(1)'; // Ukuran link normal
        this.style.fontSize = '13px'; // Ukuran teks normal
    });
});

async function fetchStoreData(storeId) {
    const response = await fetch(`/fetch_promotions.php?store_id=${storeId}`);
    const promotions = await response.json();
    const container = document.getElementById('promotions-container');
    container.innerHTML = promotions.map(promotion => `
        <div class="promotion-card">
            <img src="${promotion.image_path}" alt="${promotion.title}">
            <h3>${promotion.title}</h3>
            <p>${promotion.description}</p>
        </div>
    `).join('');
}



document.getElementById('storeForm').addEventListener('submit', function() {
    const selectedStore = document.getElementById('store_id').value;
    document.querySelector('input[name="store_id"]').value = selectedStore;
});
document.getElementById('promo-form').addEventListener('submit', async function(event) {
    event.preventDefault();

    const formData = new FormData(this);
    try {
        const response = await fetch('add_promotion.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();
        if (result.success) {
            // Tambahkan promosi baru ke tabel
            const promotionList = document.getElementById('promotion-list');
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
                <td>${result.data.id}</td>
                <td>${result.data.title}</td>
                <td>${result.data.description}</td>
                <td><img src="${result.data.image_path}" alt="Promo Image"></td>
                <td class="action-icons">
                    <i class="fas fa-edit" onclick="showEditModal(${JSON.stringify(result.data)})"></i>
                    <i class="fas fa-trash" onclick="deletePromotion(${result.data.id})"></i>
                </td>`;
            promotionList.appendChild(newRow);

            // Reset form setelah submit berhasil
            this.reset();
            alert('Promosi berhasil ditambahkan!');
        } else {
            alert('Gagal menambahkan promosi: ' + result.error);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Terjadi kesalahan. Silakan coba lagi.');
    }
});


function showEditModal(id, title, description, imagePath) {
    document.getElementById("edit-id").value = id;
    document.getElementById("edit-title").value = title;
    document.getElementById("edit-description").value = description;

    const modal = document.getElementById("editModal");
    modal.style.display = "block";
}

function closeEditModal() {
    const modal = document.getElementById("editModal");
    modal.style.display = "none";
}
async function deletePromotion(id) {
    if (!confirm("Apakah Anda yakin ingin menghapus promosi ini?")) return;

    try {
        const response = await fetch(`delete_promotion.php?id=${id}`, { method: 'GET' });
        const result = await response.json();
        if (result.success) {
            document.getElementById(`promo-${id}`).remove();
            alert("Promosi berhasil dihapus.");
        } else {
            alert("Gagal menghapus promosi: " + result.error);
        }
    } catch (error) {
        console.error("Error:", error);
        alert("Terjadi kesalahan. Silakan coba lagi.");
    }
}
