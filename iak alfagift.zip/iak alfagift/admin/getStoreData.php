<?php
// getStoreData.php
$storeId = $_GET['store_id'];
$response = array();

// Dashboard data
$sql = "SELECT 
            (SELECT COUNT(*) FROM orders WHERE store_id = ?) AS active_orders,
            (SELECT COUNT(*) FROM promotions WHERE store_id = ?) AS active_promos,
            (SELECT SUM(total_price) FROM orders WHERE store_id = ?) AS total_sales";
$stmt = $conn->prepare($sql);
$stmt->bind_param('iii', $storeId, $storeId, $storeId);
$stmt->execute();
$result = $stmt->get_result();
$response['dashboard'] = $result->fetch_assoc();

// Products
$sql = "SELECT * FROM products WHERE store_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $storeId);
$stmt->execute();
$result = $stmt->get_result();
$response['products'] = $result->fetch_all(MYSQLI_ASSOC);

// Promotions
$sql = "SELECT * FROM promotions WHERE store_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $storeId);
$stmt->execute();
$result = $stmt->get_result();
$response['promotions'] = $result->fetch_all(MYSQLI_ASSOC);

// Payments
$sql = "SELECT * FROM payments WHERE store_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $storeId);
$stmt->execute();
$result = $stmt->get_result();
$response['payments'] = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode($response);
?>
