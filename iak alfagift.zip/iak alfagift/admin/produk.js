function loadPage(page) {
    // Hapus menu aktif sebelumnya
    const menuItems = document.querySelectorAll('.menu li');
    menuItems.forEach((item) => item.classList.remove('active'));

    // Tambahkan menu aktif ke menu yang dipilih
    const selectedMenu = document.querySelector(`a[href="#${page}"]`).parentElement;
    selectedMenu.classList.add('active');

    const content = document.getElementById("content");
    let htmlContent = "";

    if (page === "dashboard") {
        htmlContent = `
            <div class="dashboard">
                <div class="stats">
                    <div class="stat-card">
                        <h3>Total Penjualan</h3>
                        <p>Rp 120.000.000</p>
                    </div>
                    <div class="stat-card">
                        <h3>Pesanan Aktif</h3>
                        <p>45 Pesanan</p>
                    </div>
                    <div class="stat-card">
                        <h3>Promo Aktif</h3>
                        <p>10 Promo</p>
                    </div>
                </div>
                <div class="notifications">
                    <h3>Notifikasi</h3>
                    <ul>
                        <li>Pesanan #1023 telah dikirim</li>
                        <li>Pembayaran #2044 menunggu verifikasi</li>
                        <li>Promo "Diskon Akhir Tahun" berhasil dibuat</li>
                    </ul>
                </div>
            </div>
        `;
    } else {
        htmlContent = `<p>Halaman belum tersedia.</p>`;
    }

    content.innerHTML = htmlContent;
}

document.querySelectorAll('.menu li a').forEach(link => {
    link.addEventListener('mouseenter', function() {
        // Membesarkan ikon dan teks saat kursor masuk
        this.querySelector('i').style.fontSize = '20px'; // Ukuran ikon membesar
        this.style.transform = 'scale(1.1)'; // Seluruh link membesar
        this.style.fontSize = '15px'; // Ukuran teks membesar
    });

    link.addEventListener('mouseleave', function() {
        // Kembali ke ukuran semula saat kursor keluar
        this.querySelector('i').style.fontSize = '20px'; // Ukuran ikon normal
        this.style.transform = 'scale(1)'; // Ukuran link normal
        this.style.fontSize = '13px'; // Ukuran teks normal
    });
});

async function fetchProductData(storeId) {
    const response = await fetch(`/fetch_products.php?store_id=${storeId}`);
    const products = await response.json();
    const container = document.getElementById('products-container');
    container.innerHTML = products.map(product => `
        <div class="product-card">
            <img src="${product.image_path}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.description}</p>
            <p>Harga: Rp ${product.price}</p>
            <p>Stok: ${product.stock}</p>
        </div>
    `).join('');
}



document.getElementById('storeForm').addEventListener('submit', function() {
    const selectedStore = document.getElementById('store_id').value;
    document.querySelector('input[name="store_id"]').value = selectedStore;
});
document.getElementById('product-form').addEventListener('submit', async function (event) {
    event.preventDefault();

    const formData = new FormData(this);
    try {
        const response = await fetch('add_product.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();
        if (result.success) {
            const productList = document.getElementById('product-list');
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
                <td>${result.data.id}</td>
                <td>${result.data.name}</td>
                <td>${result.data.description}</td>
                <td>Rp ${result.data.price}</td>
                <td>${result.data.stock}</td>
                <td><img src="${result.data.image_path}" alt="Product Image"></td>
                <td class="action-icons">
                    <i class="fas fa-edit" onclick="showEditModal(${JSON.stringify(result.data)})"></i>
                    <i class="fas fa-trash" onclick="deleteProduct(${result.data.id})"></i>
                </td>`;
            productList.appendChild(newRow);

            this.reset();
            alert('Produk berhasil ditambahkan!');
        } else {
            alert('Gagal menambahkan produk: ' + result.error);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Terjadi kesalahan. Silakan coba lagi.');
    }
});


// ini aja yang diubah
function showEditModal(id, name, description, price, stock, imagePath) {
    document.getElementById("edit-id").value = id;
    document.getElementById("edit-name").value = name;
    document.getElementById("edit-description").value = description;
    document.getElementById("edit-price").value = price;
    document.getElementById("edit-stock").value = stock;
    document.getElementById("edit-image-path").value = imagePath; // Set current image path

    const modal = document.getElementById("editModal");
    modal.style.display = "block";
}

function closeEditModal() {
    const modal = document.getElementById("editModal");
    modal.style.display = "none";
}


function closeEditModal() {
    const modal = document.getElementById("editModal");
    modal.style.display = "none";
}

async function deleteProduct(id) {
    if (!confirm("Apakah Anda yakin ingin menghapus produk ini?")) return;

    try {
        const response = await fetch(`delete_product.php?id=${id}`, { method: 'GET' });
        const result = await response.json();
        if (result.success) {
            document.getElementById(`product-${id}`).remove(); // Remove the product row from the DOM
            alert("Produk berhasil dihapus.");
        } else {
            alert("Gagal menghapus produk: " + result.error);
        }
    } catch (error) {
        console.error("Error:", error);
        alert("Terjadi kesalahan. Silakan coba lagi.");
    }
}
