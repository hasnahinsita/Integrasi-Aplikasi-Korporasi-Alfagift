<?php
$mysqli = new mysqli("localhost", "root", "", "alfagift");

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Hapus promosi dari database
    $query = $mysqli->prepare("DELETE FROM promotions WHERE id = ?");
    $query->bind_param("i", $id);

    if ($query->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $mysqli->error]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'ID tidak ditemukan.']);
}
?>
