<?php
$mysqli = new mysqli("localhost", "root", "", "alfagift");

// Periksa koneksi database
if ($mysqli->connect_error) {
    echo json_encode(['success' => false, 'error' => $mysqli->connect_error]);
    exit;
}

// Periksa apakah ID produk ada
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query untuk menghapus produk berdasarkan ID
    $query = $mysqli->prepare("DELETE FROM products WHERE id = ?");
    $query->bind_param("i", $id);

    if ($query->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $mysqli->error]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'ID produk tidak ditemukan.']);
}

$mysqli->close();
?>
