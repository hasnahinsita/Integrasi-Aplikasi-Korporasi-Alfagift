function loadPage(page) {
    // Hapus menu aktif sebelumnya
    const menuItems = document.querySelectorAll('.menu li');
    menuItems.forEach((item) => item.classList.remove('active'));

    // Tambahkan menu aktif ke menu yang dipilih
    const selectedMenu = document.querySelector(`a[href="#${page}"]`).parentElement;
    selectedMenu.classList.add('active');

    const content = document.getElementById("content");
    let htmlContent = "";

}

document.querySelectorAll('.menu li a').forEach(link => {
    link.addEventListener('mouseenter', function() {
        // Membesarkan ikon dan teks saat kursor masuk
        this.querySelector('i').style.fontSize = '20px'; // Ukuran ikon membesar
        this.style.transform = 'scale(1.1)'; // Seluruh link membesar
        this.style.fontSize = '15px'; // Ukuran teks membesar
    });

    link.addEventListener('mouseleave', function() {
        // Kembali ke ukuran semula saat kursor keluar
        this.querySelector('i').style.fontSize = '20px'; // Ukuran ikon normal
        this.style.transform = 'scale(1)'; // Ukuran link normal
        this.style.fontSize = '13px'; // Ukuran teks normal
    });
});
function fetchStoreData(store) {
    fetch('fetch_data.php?store=' + store)
        .then(response => response.json())
        .then(data => {
            // Update the dashboard with fetched data
            updateDashboard(data);
        })
        .catch(error => console.error('Error:', error));
}

function updateDashboard(data) {
    // Replace dashboard content dynamically
    document.querySelector('.stats-container').innerHTML = `
        <div class="stats-row">
            <div class="stats-card">
                <h3>Pesanan Aktif</h3>
                <p>${data.active_orders} Pesanan</p>
            </div>
            <div class="stats-card">
                <h3>Promo Aktif</h3>
                <p>${data.active_promos} Promo</p>
            </div>
        </div>
        <div class="stats-card stats-bottom">
            <h3>Total Penjualan</h3>
            <p>Rp ${data.total_sales}</p>
        </div>
    `;
}
function fetchStoreData(storeId) {
    fetch(`/api/getStoreData.php?store_id=${storeId}`)
        .then(response => response.json())
        .then(data => {
            // Perbarui UI
            updateDashboard(data.dashboard);
            updateProducts(data.products);
            updatePromotions(data.promotions);
            updatePayments(data.payments);
        });
}
function updateDashboard(dashboardData) {
    document.querySelector('.stats-container .stats-card:nth-child(1) p').innerText = `${dashboardData.active_orders} Pesanan`;
    document.querySelector('.stats-container .stats-card:nth-child(2) p').innerText = `${dashboardData.active_promos} Promo`;
    document.querySelector('.stats-card.stats-bottom p').innerText = `Rp ${dashboardData.total_sales}`;
}
function fetchStoreData(storeId) {
    fetch(`/api/getStoreData.php?store_id=${storeId}`)
        .then(response => response.json())
        .then(data => {
            // Update dashboard content
            updateDashboard(data.dashboard);
            updateProducts(data.products);
            updatePromotions(data.promotions);
            updatePayments(data.payments);
        })
        .catch(error => console.error('Error:', error));
}

function updateDashboard(dashboardData) {
    document.querySelector('.stats-container .stats-card:nth-child(1) p').innerText = `${dashboardData.active_orders} Pesanan`;
    document.querySelector('.stats-container .stats-card:nth-child(2) p').innerText = `${dashboardData.active_promos} Promo`;
    document.querySelector('.stats-card.stats-bottom p').innerText = `Rp ${dashboardData.total_sales}`;
}

function updateProducts(products) {
    // Update product list based on selected store
    const productContainer = document.querySelector('.product-list');
    productContainer.innerHTML = '';
    products.forEach(product => {
        const productCard = `<div class="product-card">
            <img src="${product.image_path}" alt="${product.name}">
            <h4>${product.name}</h4>
            <p>Rp ${product.price}</p>
            <p>Stok: ${product.stock}</p>
        </div>`;
        productContainer.innerHTML += productCard;
    });
}

function updatePromotions(promotions) {
    // Update promotions based on selected store
    const promoContainer = document.querySelector('.promo-list');
    promoContainer.innerHTML = '';
    promotions.forEach(promo => {
        const promoCard = `<div class="promo-card">
            <h4>${promo.title}</h4>
            <p>${promo.description}</p>
        </div>`;
        promoContainer.innerHTML += promoCard;
    });
}

function updatePayments(payments) {
    // Update payment details based on selected store
    const paymentContainer = document.querySelector('.payment-list');
    paymentContainer.innerHTML = '';
    payments.forEach(payment => {
        const paymentCard = `<div class="payment-card">
            <p>Payment ID: ${payment.id}</p>
            <p>Amount: Rp ${payment.amount}</p>
            <p>Status: ${payment.status}</p>
        </div>`;
        paymentContainer.innerHTML += paymentCard;
    });
}
document.getElementById('store-selector').addEventListener('change', function () {
    const storeId = this.value;
    window.location.href = '?store_id=' + storeId; // Perbarui halaman sesuai toko
});
