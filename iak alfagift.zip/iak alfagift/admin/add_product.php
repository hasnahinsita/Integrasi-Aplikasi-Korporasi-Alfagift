<?php
$mysqli = new mysqli("localhost", "root", "", "alfagift");

// Periksa koneksi database
if ($mysqli->connect_error) {
    echo json_encode(['success' => false, 'error' => $mysqli->connect_error]);
    exit;
}

// Periksa apakah form dikirim via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $store_id = $_POST['store_id'];

    // Validasi input
    if (empty($name) || empty($description) || empty($price) || empty($stock) || empty($store_id)) {
        echo json_encode(['success' => false, 'error' => 'Semua field wajib diisi!']);
        exit;
    }

    // Proses upload gambar
    $image_path = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxSize = 5 * 1024 * 1024; // 5MB

        // Validasi jenis file
        if (!in_array($_FILES['image']['type'], $allowedTypes)) {
            echo json_encode(['success' => false, 'error' => 'Format gambar tidak didukung!']);
            exit;
        }

        // Validasi ukuran file
        if ($_FILES['image']['size'] > $maxSize) {
            echo json_encode(['success' => false, 'error' => 'Ukuran file terlalu besar. Maksimal 5MB.']);
            exit;
        }

        $image_name = uniqid() . "_" . basename($_FILES['image']['name']);
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_path = "uploads/" . $image_name;

        if (!move_uploaded_file($image_tmp, $image_path)) {
            echo json_encode(['success' => false, 'error' => 'Gagal mengunggah gambar.']);
            exit;
        }
    }

    // Simpan data ke database
    $query = $mysqli->prepare("INSERT INTO products (name, description, price, stock, image_path, store_id) VALUES (?, ?, ?, ?, ?, ?)");
    $query->bind_param("ssdiss", $name, $description, $price, $stock, $image_path, $store_id);

    if ($query->execute()) {
        echo json_encode([
            'success' => true,
            'data' => [
                'id' => $query->insert_id,
                'name' => $name,
                'description' => $description,
                'price' => $price,
                'stock' => $stock,
                'image_path' => $image_path
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => $mysqli->error]);
    }
}

error_log('Pesan kesalahan: ' . $mysqli->error);
?>
