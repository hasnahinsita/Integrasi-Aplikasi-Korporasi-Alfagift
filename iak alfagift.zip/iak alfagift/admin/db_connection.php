<?php
// Set pengaturan koneksi database
$host = 'localhost';  // Atau bisa alamat server jika menggunakan remote DB
$dbname = 'alfagift';  // Ganti dengan nama database Anda
$username = 'root';  // Ganti dengan username MySQL Anda
$password = '';  // Ganti dengan password MySQL Anda

try {
    // Membuat koneksi ke database menggunakan PDO
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8";
    $pdo = new PDO($dsn, $username, $password);

    // Set mode error ke exception untuk penanganan error
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Jika berhasil, menampilkan pesan (optional)
    // echo "Connected to the database successfully!";
} catch (PDOException $e) {
    // Menangani error jika koneksi gagal
    echo "Connection failed: " . $e->getMessage();
    exit();
}

// Anda bisa menggunakan $pdo untuk query ke database

?>
