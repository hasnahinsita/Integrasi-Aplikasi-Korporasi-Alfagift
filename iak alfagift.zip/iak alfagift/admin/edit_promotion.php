<?php
$mysqli = new mysqli("localhost", "root", "", "alfagift");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $store_id = $_POST['store_id'];

    $image_path = $_POST['current_image_path'];
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image_name = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_path = "uploads/" . basename($image_name);
        move_uploaded_file($image_tmp, $image_path);
    }

    $query = $mysqli->prepare("UPDATE promotions SET title = ?, description = ?, image_path = ? WHERE id = ?");
    $query->bind_param("sssi", $title, $description, $image_path, $id);

    if ($query->execute()) {
        header("Location: promo.php?store_id=$store_id");
        exit;
    } else {
        echo "Gagal mengedit promosi: " . $mysqli->error;
    }
}
?>
