<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alfagift Admin Panel</title>
    <link rel="stylesheet" href="dasboard.css">
    <script src="dasboard.js" defer></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

</head>

<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="warna">
            <aside class="sidebar">
                <div class="sidebar-header">
                    <img src="alfagiftt.png" alt="Logo Alfagift" class="logo">
                </div>
                <ul class="menu">
                    <div class="ak">
                        <li class="active">
                            <a href="#">
                                <i class="fas fa-home"></i>
                                <span>Dashboard</span>
                            </a>
                        </li>
                    </div>
                    <li class="okey">
                        <a href="produk.php">
                            <i class="fas fa-box"></i>
                            <span>Produk & Stok</span>
                        </a>
                    </li>
                    <li>
                        <a href="payment.php">
                            <i class="fas fa-credit-card"></i>
                            <span>Verifikasi Pembayaran</span>
                        </a>
                    </li>
                    <li>
                        <a href="promo.php">
                            <i class="fas fa-tags"></i>
                            <span>Paket Promo</span>
                        </a>
                    </li>
                    <li>
                        <a href="itemcar.php">
                            <i class="fas fa-clipboard-list"></i>
                            <span>Order Items</span>
                        </a>
                    </li>
                    <li>
                    <li>
                        <a href="orders.php">
                            <i class="fas fa-list-alt"></i>
                            <span>Orders</span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                </ul>
            </aside>
        </div>

        <!-- Main Content -->
        <main class="main-content">
            <header class="header">
                <h1>Dashboard</h1>
                <div class="store-selector">
                    <label for="store">Pilih Toko:</label>
                    <select id="store-selector" onchange="fetchStoreData(this.value)">
                        <option value="1">Alfamart Kamal</option>
                        <option value="2">Alfamart Telang</option>
                    </select>

                </div>
            </header>
            <section id="content">
                <div class="dashboard">
                    <div class="top-row">
                        <div class="stats-container">
                            <div class="stats-row">
                                <div class="stats-card">
                                    <h3>Pesanan Aktif</h3>
                                    <?php
                                    // Koneksi ke database
                                    $conn = new mysqli('localhost', 'root', '', 'alfagift');
                                    if ($conn->connect_error) {
                                        die("Connection failed: " . $conn->connect_error);
                                    }

                                    // Query untuk Pesanan Aktif
                                    $ordersQuery = "SELECT COUNT(*) AS active_orders FROM orders WHERE status IN ('pending', 'processed', 'shipped')";
                                    $ordersResult = $conn->query($ordersQuery);
                                    $activeOrders = $ordersResult->fetch_assoc()['active_orders'] ?? 0;

                                    echo "<p>{$activeOrders} Pesanan</p>";
                                    ?>
                                </div>
                                <div class="stats-card">
                                    <h3>Promo Aktif</h3>
                                    <?php
                                    // Query untuk Promo Aktif
                                    $promosQuery = "SELECT COUNT(*) AS total_promos FROM promotions";
                                    $promosResult = $conn->query($promosQuery);
                                    $totalPromos = $promosResult->fetch_assoc()['total_promos'] ?? 0;

                                    echo "<p>{$totalPromos} Promo</p>";
                                    ?>
                                </div>
                            </div>
                            <div class="stats-card stats-bottom">
                                <h3>Total Penjualan</h3>
                                <?php
                                // Query untuk Total Penjualan
                                // Query untuk Total Penjualan
                                $salesQuery = "SELECT SUM(COALESCE(total_price, 0)) AS total_sales FROM orders WHERE status = 'completed'";
                                $salesResult = $conn->query($salesQuery);

                                if ($salesResult) {
                                    $row = $salesResult->fetch_assoc();
                                    $totalSales = $row['total_sales'] ?? 0;
                                    echo "<p>Rp " . number_format($totalSales, 0, ',', '.') . "</p>";
                                } else {
                                    echo "<p>Error: " . $conn->error . "</p>";
                                }



                                ?>
                            </div>
                        </div>

                        <div class="image-container">
                            <img src="001.png" class="flip-horizontal" alt="Image">
                        </div>
                    </div>
                    <div class="notifications">
                        <h3>Notifikasi</h3>
                        <ul>
                            <?php
                            // Koneksi ke database
                            $conn = new mysqli('localhost', 'root', '', 'alfagift');

                            // Periksa koneksi
                            if ($conn->connect_error) {
                                die("Connection failed: " . $conn->connect_error);
                            }

                            // Ambil notifikasi terbaru
                            $notifQuery = "SELECT message, created_at FROM notifications ORDER BY created_at DESC LIMIT 10";
                            $notifResult = $conn->query($notifQuery);

                            // Periksa hasil query
                            if ($notifResult && $notifResult->num_rows > 0) {
                                // Tampilkan notifikasi
                                while ($notif = $notifResult->fetch_assoc()) {
                                    echo "<li>" . htmlspecialchars($notif['message']) . " <span class='notif-time'>(" . htmlspecialchars($notif['created_at']) . ")</span></li>";
                                }
                            } else {
                                // Jika tidak ada notifikasi
                                echo "<li>Tidak ada notifikasi baru.</li>";
                            }

                            // Tutup koneksi
                            $conn->close();
                            ?>
                        </ul>
                    </div>

                </div>
            </section>


        </main>
    </div>

</body>

</html>