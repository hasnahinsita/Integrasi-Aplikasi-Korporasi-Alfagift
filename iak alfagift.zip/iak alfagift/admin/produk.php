<?php
$mysqli = new mysqli("localhost", "root", "", "alfagift");

if ($mysqli->connect_error) {
    echo json_encode(['success' => false, 'error' => $mysqli->connect_error]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $store_id = $_POST['store_id'];

    $image_path = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $maxFileSize = 5 * 1024 * 1024; // 5MB

        if ($_FILES['image']['size'] > $maxFileSize) {
            echo json_encode([
                'success' => false,
                'error' => 'Ukuran file terlalu besar. Maksimum adalah 5MB.'
            ]);
            exit;
        }

        $image_name = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_path = "uploads/" . basename($image_name);

        if (!move_uploaded_file($image_tmp, $image_path)) {
            echo json_encode(['success' => false, 'error' => 'Gagal mengunggah gambar.']);
            exit;
        }
    }

    $query = $mysqli->prepare("INSERT INTO products (store_id, name, description, price, stock, image_path) VALUES (?, ?, ?, ?, ?, ?)");
    $query->bind_param("issdis", $store_id, $name, $description, $price, $stock, $image_path);

    if ($query->execute()) {
        echo json_encode([
            'success' => true,
            'data' => [
                'id' => $query->insert_id,
                'name' => $name,
                'description' => $description,
                'price' => $price,
                'stock' => $stock,
                'image_path' => $image_path
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => $mysqli->error]);
    }
}

// Ambil daftar toko untuk dropdown
$query = "SELECT id, name FROM stores";
$result = $mysqli->query($query);
if (!$result) {
    die("Error: " . $mysqli->error);
}

// Cek apakah ada toko yang dipilih
$store_id = isset($_GET['store_id']) ? $_GET['store_id'] : '';

// Query untuk mengambil data produk berdasarkan toko yang dipilih
if ($store_id) {
    $query = $mysqli->prepare("SELECT * FROM products WHERE store_id = ?");
    $query->bind_param("i", $store_id);
} else {
    $query = $mysqli->prepare("SELECT * FROM products");
}

$query->execute();
$result_products = $query->get_result();
$products = $result_products->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alfagift Admin Panel</title>
    <link rel="stylesheet" href="produk.css">
    <script src="produk.js" defer></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

</head>

<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="warna">
            <aside class="sidebar">
                <div class="sidebar-header">
                    <img src="alfagiftt.png" alt="Logo Alfagift" class="logo">
                </div>
                <ul class="menu">

                    <li class="oki">
                        <a href="dasboard.php">
                            <i class="fas fa-home"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <div class="ak">
                        <li class="active">
                            <a href="produk.php">
                                <i class="fas fa-box"></i>
                                <span>Produk & Stok</span>
                            </a>
                        </li>
                    </div>
                    <li class="okey">
                        <a href="payment.php">
                            <i class="fas fa-credit-card"></i>
                            <span>Verifikasi Pembayaran</span>
                        </a>
                    </li>
                    <li>
                        <a href="promo.php">
                            <i class="fas fa-tags"></i>
                            <span>Paket Promo</span>
                        </a>
                    </li>

                    <li>
                    <a href="itemcar.php">
                                <i class="fas fa-clipboard-list"></i>
                                <span>Order Items</span>
                            </a>
                    </li>
                    <li>
                    <li>
                    <a href="orders.php">
    <i class="fas fa-list-alt"></i>
    <span>Orders</span>
</a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                </ul>
            </aside>
        </div>

        <!-- Main Content -->
        <main class="main-content">
            <header class="header">
                <h1>Product</h1>
                <form method="GET" id="storeForm">
                    <label for="store_id">Pilih Toko:</label>
                    <select name="store_id" id="store_id" onchange="this.form.submit()">
                        <option value="">-- Pilih Toko --</option>
                        <?php
                        // Tampilkan pilihan toko dalam dropdown
                        while ($row = mysqli_fetch_assoc($result)) {
                            // Mengecek jika store_id sudah dipilih sebelumnya, maka memberi atribut 'selected'
                            $selected = (isset($_GET['store_id']) && $_GET['store_id'] == $row['id']) ? 'selected' : '';
                            echo "<option value='" . $row['id'] . "' $selected>" . $row['name'] . "</option>";
                        }
                        ?>
                    </select>
                </form>
            </header>
            <div class="product-list">
                <table class="product-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama Produk</th>
                            <th>Deskripsi</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th>Gambar</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="product-list">
                        <?php foreach ($products as $product): ?>
                            <tr id="product-<?= $product['id'] ?>">
                                <td><?= $product['id'] ?></td>
                                <td><?= $product['name'] ?></td>
                                <td><?= $product['description'] ?></td>
                                <td>Rp <?= $product['price'] ?></td>
                                <td><?= $product['stock'] ?></td>
                                <td><img src="<?= $product['image_path'] ?>" alt="Product Image"></td>
                                <td class="action-icons">
                                    <i class="fas fa-edit" onclick="showEditModal(<?= $product['id'] ?>, '<?= $product['name'] ?>', '<?= $product['description'] ?>', <?= $product['price'] ?>, <?= $product['stock'] ?>, '<?= $product['image_path'] ?>')"></i>
                                    <i class="fas fa-trash" onclick="deleteProduct(<?= $product['id'] ?>)"></i>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="form-container">
                <form id="product-form" method="POST" enctype="multipart/form-data" action="add_product.php">
                    <input type="text" name="name" placeholder="Nama Produk" required>
                    <textarea name="description" placeholder="Deskripsi Produk" required></textarea>
                    <input type="number" name="price" placeholder="Harga Produk" step="0.01" required>
                    <input type="number" name="stock" placeholder="Jumlah Stok" required>
                    <input type="file" name="image" accept="image/*" required>
                    <input type="hidden" name="store_id" value="<?= htmlspecialchars($store_id) ?>">
                    <button type="submit">Tambah Produk</button>
                </form>

            </div>

        </main>
    </div>
    <div id="editModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeEditModal()">&times;</span>
        <h2>Edit Produk</h2>
        <form id="edit-form" method="POST" enctype="multipart/form-data" action="edit_product.php">
            <input type="hidden" name="id" id="edit-id">
            <input type="text" name="name" id="edit-name" placeholder="Nama Produk" required>
            <textarea name="description" id="edit-description" placeholder="Deskripsi" required></textarea>
            <input type="number" name="price" id="edit-price" placeholder="Harga" required>
            <input type="number" name="stock" id="edit-stock" placeholder="Stok" required>
            <input type="file" name="image" accept="image/*">
            <input type="hidden" name="image_path" id="edit-image-path"> <!-- Hidden input for current image -->
            <button type="submit">Simpan Perubahan</button>
        </form>
    </div>
</div>








</body>

</html>