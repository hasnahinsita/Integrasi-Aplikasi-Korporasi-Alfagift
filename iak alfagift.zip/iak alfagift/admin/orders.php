<?php
$mysqli = new mysqli("localhost", "root", "", "alfagift");

if ($mysqli->connect_error) {
    echo json_encode(['success' => false, 'error' => $mysqli->connect_error]);
    exit;
}

// Ambil data toko
$query_stores = "SELECT id, name FROM stores";
$result_stores = $mysqli->query($query_stores);
if (!$result_stores) {
    die("Error: " . $mysqli->error);
}

$query_orders = "SELECT o.id, o.store_id, o.user_id, o.product_id, o.quantity, o.total_price, 
                        o.first_name, o.last_name, o.phone, o.address, o.shipping_method,
                        o.status, o.created_at, s.name AS store_name
                 FROM orders o
                 JOIN stores s ON o.store_id = s.id";

$result_orders = $mysqli->query($query_orders);

// Debug jika query gagal
if (!$result_orders) {
    die("Query Error: " . $mysqli->error);
}

$orders = $result_orders->fetch_all(MYSQLI_ASSOC);

// Handle form submission for status update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['order_id'], $_POST['status'])) {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];

    // Update query untuk status
    $update_query = "UPDATE orders SET status = ? WHERE id = ?";
    $stmt = $mysqli->prepare($update_query);
    $stmt->bind_param('si', $status, $order_id);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Status updated successfully!']);
    } else {
        echo json_encode(['success' => false, 'error' => $mysqli->error]);
    }
    $stmt->close();
}


?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alfagift Admin Panel</title>
    <link rel="stylesheet" href="itemcart.css">
    <script src="itemcart.js" defer></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

</head>

<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="warna">
            <aside class="sidebar">
                <div class="sidebar-header">
                    <img src="alfagiftt.png" alt="Logo Alfagift" class="logo">
                </div>
                <ul class="menu">

                    <li>
                        <a href="dasboard.php">
                            <i class="fas fa-home"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>

                    <li>
                        <a href="produk.php">
                            <i class="fas fa-box"></i>
                            <span>Produk & Stok</span>
                        </a>
                    </li>
               
                        <li>
                            <a href="payment.php">
                                <i class="fas fa-credit-card"></i>
                                <span>Verifikasi Pembayaran</span>
                            </a>
                        </li>
                 
                    <li>
                        <a href="promo.php">
                            <i class="fas fa-tags"></i>
                            <span>Paket Promo</span>
                        </a>
                    </li>

                    <li  class="oki">

                        <a href="itemcar.php">
                            <i class="fas fa-clipboard-list"></i>
                            <span>Order Items</span>
                        </a>
                    </li>

                    <div class="ak">
                        <li class="active">
                        <a href="orders.php">
                            <i class="fas fa-clipboard-list"></i>
                            <span>Orders</span>
                        </a>
                    </li>
                    </div>
                    <li  class="okey">
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                </ul>
            </aside>
        </div>

        <!-- Main Content -->
        <main class="main-content">
            <header class="header">
                <h1>Orders</h1>
                <form method="GET" id="storeForm">
                    <label for="store_id">Pilih Toko:</label>
                    <select name="store_id" id="store_id" onchange="this.form.submit()">
                        <option value="">-- Pilih Toko --</option>
                        <?php
                        // Tampilkan pilihan toko dalam dropdown
                        while ($row = mysqli_fetch_assoc($result_stores)) {
                            $selected = (isset($_GET['store_id']) && $_GET['store_id'] == $row['id']) ? 'selected' : '';
                            echo "<option value='" . $row['id'] . "' $selected>" . $row['name'] . "</option>";
                        }

                        ?>
                    </select>
                </form>
            </header>
            <table class="product-table">
                <thead>
                    <tr>
                        <th>ID Pesanan</th>
                        <th>Toko</th>
                        <th>Nama Pembeli</th>

                        <th>Phone Pembeli</th>
                        <th>Alamat Pembeli</th>

                        <th>Jumlah</th>
                        <th>Total Harga</th>
                        <th>Metode Pengiriman</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($orders)): ?>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td><?= $order['id'] ?></td>
                                <td><?= $order['store_name'] ?></td>
                                <td><?= $order['first_name'] ?> <?= $order['last_name'] ?></td>

                                <td><?= $order['phone'] ?></td>
                                <td><?= $order['address'] ?></td>

                                <td><?= $order['quantity'] ?></td>
                                <td><?= number_format($order['total_price'], 2) ?></td>
                                <td><?= $order['shipping_method'] ?></td>
                                <td><?= $order['status'] ?></td>
                                <td>
                                <form method="POST" class="update-status-form">
    <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
    <select name="status">
        <option value="pending" <?= $order['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
        <option value="processed" <?= $order['status'] == 'processed' ? 'selected' : '' ?>>Processed</option>
        <option value="shipped" <?= $order['status'] == 'shipped' ? 'selected' : '' ?>>Shipped</option>
        <option value="completed" <?= $order['status'] == 'completed' ? 'selected' : '' ?>>Completed</option>
        <option value="cancelled" <?= $order['status'] == 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
    </select>
    <button type="submit">Update Status</button>
</form>

</td>





                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="12" style="text-align:center;">Tidak ada data pesanan</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>


    </div>

    </div>
    <script>
      document.querySelectorAll('.update-status-form').forEach(form => {
    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const formData = new FormData(form);

        // Kirim data menggunakan AJAX
        fetch('orders.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Dapatkan nilai status yang dipilih
                const selectedStatus = form.querySelector('select').value;

                // Temukan elemen kolom status di baris tabel
                const statusCell = form.closest('tr').querySelector('td:nth-child(9)');
                
                // Update nilai status di kolom tabel
                statusCell.textContent = selectedStatus;

                // Jika perlu, Anda juga dapat memperbarui nilai di dropdown status
                form.querySelector('select').value = selectedStatus;

                alert(data.message); // Tampilkan pesan sukses
            } else {
                alert('Error: ' + data.error);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
    });
});


    </script>


</body>

</html>