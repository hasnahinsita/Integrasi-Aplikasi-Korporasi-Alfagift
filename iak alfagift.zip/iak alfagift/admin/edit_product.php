<?php
$mysqli = new mysqli("localhost", "root", "", "alfagift");

// Periksa koneksi database
if ($mysqli->connect_error) {
    echo json_encode(['success' => false, 'error' => $mysqli->connect_error]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $image_path = $_POST['image_path'];  // Existing image path

    // Validasi input
    if (empty($id) || empty($name) || empty($description) || empty($price) || empty($stock)) {
        echo json_encode(['success' => false, 'error' => 'Semua field wajib diisi!']);
        exit;
    }

    // Proses upload gambar (jika ada)
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxSize = 5 * 1024 * 1024; // 5MB

        // Validasi jenis file
        if (!in_array($_FILES['image']['type'], $allowedTypes)) {
            echo json_encode(['success' => false, 'error' => 'Format gambar tidak didukung!']);
            exit;
        }

        // Validasi ukuran file
        if ($_FILES['image']['size'] > $maxSize) {
            echo json_encode(['success' => false, 'error' => 'Ukuran file terlalu besar. Maksimal 5MB.']);
            exit;
        }

        $image_name = uniqid() . "_" . basename($_FILES['image']['name']);
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_path = "uploads/" . $image_name;

        if (!move_uploaded_file($image_tmp, $image_path)) {
            echo json_encode(['success' => false, 'error' => 'Gagal mengunggah gambar.']);
            exit;
        }
    }

    // Update data produk ke database
    $query = $mysqli->prepare("UPDATE products SET name = ?, description = ?, price = ?, stock = ?, image_path = ? WHERE id = ?");
    $query->bind_param("ssdiss", $name, $description, $price, $stock, $image_path, $id);

    if ($query->execute()) {
        // Redirect ke halaman produk.php setelah berhasil
        header("Location: produk.php?success=true");
        exit;
    } else {
        echo json_encode(['success' => false, 'error' => $mysqli->error]);
        exit;
    }
}

error_log('Pesan kesalahan: ' . $mysqli->error);
?>
