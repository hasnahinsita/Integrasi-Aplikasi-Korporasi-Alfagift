<?php
$mysqli = new mysqli("localhost", "root", "", "alfagift");

if ($mysqli->connect_error) {
    echo json_encode(['success' => false, 'error' => $mysqli->connect_error]);
    exit;
}

// Ambil data order_items dari tabel
$query_order_items = "SELECT oi.id, oi.order_id, oi.product_id, oi.quantity, oi.price, 
                      o.first_name, o.last_name, p.name AS product_name
                      FROM order_items oi
                      JOIN orders o ON oi.order_id = o.id
                      JOIN products p ON oi.product_id = p.id";

$result_order_items = $mysqli->query($query_order_items);

if (!$result_order_items) {
    die("Error: " . $mysqli->error);
}

// Ambil data order_items dalam bentuk array
$order_items = $result_order_items->fetch_all(MYSQLI_ASSOC);



// Ambil daftar toko untuk dropdown
$query = "SELECT id, name FROM stores";
$result = $mysqli->query($query);
if (!$result) {
    die("Error: " . $mysqli->error);
}

// Cek apakah ada toko yang dipilih
$store_id = isset($_GET['store_id']) ? $_GET['store_id'] : '';

// Query untuk mengambil data produk berdasarkan toko yang dipilih
if ($store_id) {
    $query = $mysqli->prepare("SELECT * FROM products WHERE store_id = ?");
    $query->bind_param("i", $store_id);
} else {
    $query = $mysqli->prepare("SELECT * FROM products");
}

$query->execute();
$result_products = $query->get_result();
$products = $result_products->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alfagift Admin Panel</title>
    <link rel="stylesheet" href="itemcart.css">
    <script src="itemcart.js" defer></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

</head>

<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="warna">
            <aside class="sidebar">
                <div class="sidebar-header">
                    <img src="alfagiftt.png" alt="Logo Alfagift" class="logo">
                </div>
                <ul class="menu">

                    <li >
                        <a href="dasboard.php">
                            <i class="fas fa-home"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>

                    <li>
                        <a href="produk.php">
                            <i class="fas fa-box"></i>
                            <span>Produk & Stok</span>
                        </a>
                    </li>

                    <li>
                        <a href="payment.php">
                            <i class="fas fa-credit-card"></i>
                            <span>Verifikasi Pembayaran</span>
                        </a>
                    </li>
                    <li class="oki">
                        <a href="promo.php">
                            <i class="fas fa-tags"></i>
                            <span>Paket Promo</span>
                        </a>
                    </li>
                    <div class="ak">
                        <li class="active">

                            <a href="order_items.php">
                                <i class="fas fa-clipboard-list"></i>
                                <span>Order Items</span>
                            </a>
                        </li>
                    </div>
                    <li class="okey">
                   
                    <a href="orders.php">
    <i class="fas fa-list-alt"></i>
    <span>Orders</span>
</a>
                 
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                    <li>
                        <a>
                            <i></i>
                            <span></span>
                        </a>
                    </li>
                </ul>
            </aside>
        </div>

        <!-- Main Content -->
        <main class="main-content">
            <header class="header">
                <h1>Order Item</h1>
                <form method="GET" id="storeForm">
                    <label for="store_id">Pilih Toko:</label>
                    <select name="store_id" id="store_id" onchange="this.form.submit()">
                        <option value="">-- Pilih Toko --</option>
                        <?php
                        // Tampilkan pilihan toko dalam dropdown
                        while ($row = mysqli_fetch_assoc($result)) {
                            // Mengecek jika store_id sudah dipilih sebelumnya, maka memberi atribut 'selected'
                            $selected = (isset($_GET['store_id']) && $_GET['store_id'] == $row['id']) ? 'selected' : '';
                            echo "<option value='" . $row['id'] . "' $selected>" . $row['name'] . "</option>";
                        }
                        ?>
                    </select>
                </form>
            </header>
            <table class="product-table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Order ID</th>
            <th>Product Name</th>
            <th>Quantity</th>
            <th>Price</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!empty($order_items)): ?>
            <?php foreach ($order_items as $item): ?>
                <tr>
                    <td><?= $item['id'] ?></td>
                    <td><?= $item['order_id'] ?></td>
                    <td><?= $item['product_name'] ?></td>
                    <td><?= $item['quantity'] ?></td>
                    <td><?= number_format($item['price'], 2) ?></td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="5" style="text-align:center;">Tidak ada data order items</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>


    </div>


    </main>
    </div>
</body>

</html>