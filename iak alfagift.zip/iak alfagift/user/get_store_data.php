<?php
// Misalnya menggunakan koneksi database yang sudah ada
$storeId = $_GET['store_id'];
$response = [];

if ($storeId) {
    $query = "SELECT * FROM products WHERE store_id = $storeId";
    $result = $conn->query($query);

    if ($result) {
        while ($product = $result->fetch_assoc()) {
            $response['products'][] = [
                'name' => $product['name'],
                'price' => $product['price']
            ];
        }
    }
}

// Mengembalikan data dalam format JSON
echo json_encode($response);
?>
