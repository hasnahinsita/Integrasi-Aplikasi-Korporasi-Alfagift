<?php
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'alfagift';

$conn = new mysqli($host, $user, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
