<?php
session_start(); // Untuk mengelola sesi pengguna

// Contoh: Data login dummy
// Ganti dengan logika login sebenarnya
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['email'])) {
    $_SESSION['user_email'] = $_POST['email']; // Simpan email pengguna di sesi
    header("Location: home.php"); // Arahkan kembali ke halaman utama
    exit;
}

function isLoggedIn() {
    return isset($_SESSION['user_email']);
}
