<?php
session_start();
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'alfagift';

$conn = new mysqli($host, $user, $password, $dbname);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (isset($data['itemId'], $data['quantity'])) {
        $itemId = intval($data['itemId']);
        $quantity = intval($data['quantity']);
        $userId = $_SESSION['user_id'];

        $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?");

        $stmt->bind_param("iii", $quantity, $itemId, $userId);
        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => $conn->error]);
        }
        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid data']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}
$conn->close();
?>
