<?php
session_start(); // Pastikan session dimulai sebelum memeriksa
if (!isset($_SESSION['user_email']) || !isset($_SESSION['user_id'])) {
    // Redirect ke halaman login jika session user_email atau user_id tidak ada
    header("Location: login.php");
    exit;
}

// Koneksi ke database
$servername = "localhost"; // Ganti dengan server database Anda
$username = "root"; // Ganti dengan username database Anda
$password = ""; // Ganti dengan password database Anda
$dbname = "alfagift"; // Ganti dengan nama database Anda

// Membuat koneksi
$connection = new mysqli($servername, $username, $password, $dbname);

// Mengecek koneksi
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Retrieve product data from URL parameters
$productId = isset($_GET['id']) ? $_GET['id'] : '';
$productName = isset($_GET['name']) ? $_GET['name'] : '';
$productPrice = isset($_GET['price']) ? $_GET['price'] : '';
$productImage = isset($_GET['image']) ? $_GET['image'] : '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajaxAddToCart'])) {
    // Pastikan user sudah login
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
        exit();
    }

    // Ambil data produk dari form
    $userId = $_SESSION['user_id'];  // ID user yang login
    $itemId = $_POST['id'];
    $itemName = $_POST['name'];
    $itemPrice = $_POST['price'];
    $itemQty = $_POST['qty'];
    $itemImage = $_POST['image'];

    // Cek apakah produk sudah ada di keranjang
    $stmt = $connection->prepare("SELECT quantity FROM cart WHERE user_id = ? AND product_id = ?");
    $stmt->bind_param("ii", $userId, $itemId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Produk sudah ada, update quantity
        $row = $result->fetch_assoc();
        $newQty = $row['quantity'] + $itemQty; // Menambahkan kuantitas yang baru

        // Update jumlah produk di keranjang
        $updateStmt = $connection->prepare("UPDATE cart SET quantity = ?, updated_at = NOW() WHERE user_id = ? AND product_id = ?");
        $updateStmt->bind_param("iii", $newQty, $userId, $itemId);
        if ($updateStmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'Jumlah produk berhasil diperbarui di keranjang!']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Gagal memperbarui jumlah produk di keranjang: ' . $updateStmt->error]);
        }
        $updateStmt->close();
    } else {
        // Produk belum ada, insert produk baru ke keranjang
        $stmtInsert = $connection->prepare("INSERT INTO cart (user_id, product_id, quantity, image_path, created_at, updated_at) 
                                            VALUES (?, ?, ?, ?, NOW(), NOW())");
        $stmtInsert->bind_param("iiis", $userId, $itemId, $itemQty, $itemImage);

        if ($stmtInsert->execute()) {
            // Set response untuk AJAX
            echo json_encode(['status' => 'success', 'message' => 'Produk berhasil ditambahkan ke keranjang!', 'totalItems' => $totalItems]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Gagal menambahkan produk ke keranjang: ' . $stmtInsert->error]);
        }
        $stmtInsert->close();
    }

    $stmt->close();
    $connection->close();
    exit();
}

// Inisialisasi variabel total item
$totalItems = 0;

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Query untuk menghitung jumlah total item di keranjang
    $stmt = $connection->prepare("SELECT COUNT(DISTINCT product_id) AS total FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        $row = $result->fetch_assoc();
        $totalItems = isset($row['total']) ? (int)$row['total'] : 0;
    } else {
        $totalItems = 0;
    }

    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<!-- HTML content here -->

</html>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product - Alfagift</title>
    <link rel="stylesheet" href="product.css">
    <!-- Add Font Awesome CDN link in your <head> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

</head>

<body>
    <!-- Header -->
    <header>
        <div class="top-bar">
            <div class="social-media">
                <a href="#" class='fb'><img src="faceb.png" alt="Facebook"></a>
                <a href="#"><img src="twit.png" alt="Twitter"></a>
                <a href="#"><img src="youtube.png" alt="YouTube"></a>
                <a href="#"><img src="instag.png" alt="Instagram"></a>
            </div>
            <div class="language">
                <span>Order tracking</span>
                <span>Help</span>
                <div class="dropdown">
                    <img src="US.png" alt="US Flag" class="flag">
                    <select class='bhs'>
                        <option>English (US)</option>
                        <option>Indonesia</option>
                    </select>
                </div>
            </div>

        </div>
        <div class="main-header">

            <img src="alfagift.png" alt="Alfagift Logo" class="logo">
            <div class="search-bar">

                <input type="text" placeholder="Search something...">
                <select>
                    <option class='opsi'>All Categories</option>
                </select>
                <button class='search'><img src="Search.png" alt="Search Icon"></button>

            </div>
            <nav>
                <a href="cartkamal.php" class='cart'>
                    <img src="cart.png" alt="Cart">
                    <!-- Menampilkan badge jumlah item -->
                    <span class="badge"><?php echo $totalItems; ?></span>
                </a>

                <a href="#" class='cart'><img src="love.png" alt="Wishlist"></a>
                <a href="#" class="account-section">
                    <img src="account.png" alt="Account" class='account'>
                    <div>
                        <?php if (isset($_SESSION['user_email'])): ?>
                            <span class="account-text"><?= htmlspecialchars($_SESSION['user_email']) ?></span>
                        <?php else: ?>
                            <span class="join-text">Join Alfagift</span>
                            <span class="account-text">My Account</span>
                        <?php endif; ?>
                    </div>
                </a>
            </nav>

        </div>
    </header>

    <div class="product-container">
        <!-- Product Image -->
        <div class="product-image">
            <img id="mainImage" src="../admin/<?= htmlspecialchars($productImage) ?>" alt="<?= htmlspecialchars($productName) ?>" />
        </div>

        <!-- Product Details -->
        <div class="product-details">
            <h1><?= htmlspecialchars($productName) ?></h1>
            <div class="rating">
                <span>⭐ 4.6</span>
                <span>261 Product sold</span>
                <span>3.1k Product watched</span>
            </div>
            <p>
                Originote Jelly Booster 24k Symwhite 15 ml adalah pelembab wajah multifungsi yang dirancang untuk membantu mencerahkan kulit, menyamarkan noda hitam, dan meratakan warna kulit. Dengan formulasi ringan, produk ini memberikan hidrasi optimal sekaligus meningkatkan kilau alami kulit Anda.
            </p>
            <p class="shipping">
                🚚 Dikirim oleh SAPA Instant Delivery<br>
                Biaya Pengiriman Gratis
            </p>
            <div class="price-actions">
                <!-- Harga -->
                <span class="price">Rp <?= number_format($productPrice, 0, ',', '.') ?></span>

                <!-- Container Tombol -->
                <div class="button-container">
                    <form id="addToCartForm">
                        <input type="hidden" name="id" value="<?= $productId ?>">
                        <input type="hidden" name="name" value="<?= htmlspecialchars($productName) ?>">
                        <input type="hidden" name="price" value="<?= htmlspecialchars($productPrice) ?>">
                        <input type="hidden" name="image" value="<?= htmlspecialchars($productImage) ?>">
                        <input type="hidden" name="qty" value="1">

                        <!-- Tombol Add to Cart with Icon -->
                        <button class="buttonn" type="button" id="addToCartButton">
                            <!-- Icon Keranjang dengan Font Awesome -->
                            <i class="fas fa-shopping-cart"></i> Add to Cart
                        </button>
                    </form>
                </div>



                <script>
                    document.getElementById("addToCartButton").addEventListener("click", function() {
                        const formData = new FormData(document.getElementById("addToCartForm"));

                        // Tambahkan flag untuk permintaan AJAX
                        formData.append("ajaxAddToCart", "true");

                        fetch("<?= $_SERVER['PHP_SELF'] ?>", { // Kirim permintaan ke file PHP yang sama
                                method: "POST",
                                body: formData
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.status === "success") {
                                    alert("Produk berhasil ditambahkan ke keranjang!");
                                    // Update badge jumlah item dengan total baru
                                    document.querySelector(".badge").textContent = data.totalItems;
                                } else {
                                    alert("Gagal menambahkan produk ke keranjang: " + data.message);
                                }
                            })

                            .catch(error => {
                                console.error("Error:", error);
                                alert("Terjadi kesalahan, silakan coba lagi.");
                            });
                    });
                </script>

            </div>

        </div>


    </div>
    </div>

    <script src="product.js"></script>
    <footer>
        <div class="footer-container">
            <div class="logo-section">
                <img src="alfagift.png" alt="Logo" class="logo">
            </div>
            <div class="menu-section">
                <div class="menu-column">
                    <h4>First Menu</h4>
                    <ul>
                        <li>Features</li>
                        <li>Enterprise</li>
                        <li>Security</li>
                        <li>Customer Stories</li>
                        <li>Pricing</li>
                        <li>Demo</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Second Menu</h4>
                    <ul>
                        <li>Engineering</li>
                        <li>Financial Services</li>
                        <li>Sales</li>
                        <li>IT</li>
                        <li>Customer Support</li>
                        <li>Human Resources</li>
                        <li>Media</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Third Menu</h4>
                    <ul>
                        <li>Tips</li>
                        <li>Blog</li>
                        <li>Event</li>
                        <li>Certified Program</li>
                        <li>Help Center</li>
                        <li>API</li>
                        <li>Download Template</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Fourth Menu</h4>
                    <ul>
                        <li>About Us</li>
                        <li>Leadership</li>
                        <li>News</li>
                        <li>Media Kit</li>
                        <li>Career</li>
                        <li>Documentation</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Alfagift © Copyright 2020, Inc. All rights reserved</p>
            <div class="social-media">
                <span>FB</span>
                <span>TW</span>
                <span>LN</span>
                <span>IG</span>
                <span>GH</span>
            </div>
        </div>
    </footer>
    <script>
        function changeQuantity(change) {
            const quantityInput = document.getElementById("quantity");
            let currentQuantity = parseInt(quantityInput.value);
            currentQuantity = Math.max(1, currentQuantity + change); // Prevent going below 1
            quantityInput.value = currentQuantity;
        }
    </script>
</body>

</html>