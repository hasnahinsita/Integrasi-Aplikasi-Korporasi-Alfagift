<?php
require 'db_connection.php'; // Koneksi ke database utama
require 'gopay_connection.php'; // Koneksi ke database gopay

session_start();

// Aktifkan error reporting untuk debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Pastikan pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user_id'];
$cartItems = $_POST['cart_items'] ?? [];
$firstName = $_POST['first_name'] ?? '';
$lastName = $_POST['last_name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$address = $_POST['address'] ?? '';
$shippingMethod = $_POST['shipping_method'] ?? '';
$paymentMethod = $_POST['payment_method'] ?? '';
$totalPrice = $_POST['total_price'] ?? 0;

// Validasi data
if (!$firstName || !$lastName || !$email || !$phone || !$address || !$shippingMethod || !$paymentMethod || empty($cartItems)) {
    die("All fields are required.");
}

echo "Step 1: Validating data...<br>"; // Debugging output

// Mulai transaksi
$conn->begin_transaction();
$gopayConn->begin_transaction();

try {
    // Step 2: Validasi dan perhitungan total harga dari cart
    echo "Step 2: Fetching total price from cart items...<br>"; // Debugging output

    $storeId = null;
    foreach ($cartItems as $cartId => $item) {
        $stmt = $conn->prepare("
            SELECT c.product_id, p.store_id, p.price
            FROM cart c
            JOIN products p ON c.product_id = p.id
            WHERE c.id = ?
        ");
        $stmt->bind_param("i", $cartId);
        $stmt->execute();
        $stmt->bind_result($productId, $storeIdFromCart, $price);
        $stmt->fetch();
        $stmt->close();

        if (!$productId || !$storeIdFromCart) {
            throw new Exception("Product or store not found for cart ID $cartId.");
        }

        if ($storeId === null) {
            $storeId = $storeIdFromCart;
        } elseif ($storeId !== $storeIdFromCart) {
            throw new Exception("Products from different stores can't be ordered together.");
        }

        $quantity = $item['quantity'];
        $totalPrice += $price * $quantity;
    }

    echo "Step 3: Total price calculated...<br>"; // Debugging output

    // Insert data ke tabel orders
    $stmt = $conn->prepare("
        INSERT INTO orders (store_id, user_id, first_name, last_name, email, phone, address, shipping_method, total_price)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("iissssssd", $storeId, $userId, $firstName, $lastName, $email, $phone, $address, $shippingMethod, $totalPrice);
    $stmt->execute();
    $orderId = $stmt->insert_id;
    $stmt->close();

    echo "Step 4: Order data inserted...<br>"; // Debugging output

    // Insert detail produk ke tabel order_items
    foreach ($cartItems as $cartId => $item) {
        $quantity = $item['quantity'];

        $stmt = $conn->prepare("
            SELECT c.product_id, p.price
            FROM cart c
            JOIN products p ON c.product_id = p.id
            WHERE c.id = ?
        ");
        $stmt->bind_param("i", $cartId);
        $stmt->execute();
        $stmt->bind_result($productId, $price);
        $stmt->fetch();
        $stmt->close();

        $stmt = $conn->prepare("
            INSERT INTO order_items (order_id, product_id, quantity, price)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->bind_param("iiid", $orderId, $productId, $quantity, $price);
        $stmt->execute();
        $stmt->close();
    }

    // Insert payment data ke tabel payments
    $stmt = $conn->prepare("
        INSERT INTO payments (store_id, user_id, order_id, payment_method, amount, status)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $status = 'completed';
    $stmt->bind_param("iiisds", $storeId, $userId, $orderId, $paymentMethod, $totalPrice, $status);
    $stmt->execute();
    $stmt->close();

    echo "Step 5: Payment data inserted...<br>"; // Debugging output

    // Commit transaksi untuk order
    $conn->commit();
    echo "Step 6: Order and payment committed.<br>"; // Debugging output

    // Jika payment method adalah GoPay, update saldo GoPay
    if ($paymentMethod === 'gopay') {
        echo "Step 7: Payment method is GoPay, updating balance...<br>"; // Debugging output

        // Ambil saldo GoPay dari database
        $stmt = $gopayConn->prepare("SELECT balance FROM saldo WHERE phone = ?");
        $stmt->bind_param("s", $phone);
        $stmt->execute();
        $stmt->bind_result($balance);
        $stmt->fetch();
        $stmt->close();

        if ($balance === null) {
            throw new Exception("No balance found for the phone number $phone.");
        }

        // Periksa apakah saldo cukup
        if ($balance < $totalPrice) {
            throw new Exception("Insufficient balance in GoPay.");
        }

        // Kurangi saldo GoPay
        $newBalance = $balance - $totalPrice;
        $stmt = $gopayConn->prepare("UPDATE saldo SET balance = ? WHERE phone = ?");
        $stmt->bind_param("ds", $newBalance, $phone);
        $stmt->execute();
        $stmt->close();

        // Commit transaksi di database GoPay
        $gopayConn->commit();
        echo "Step 8: GoPay balance updated and committed.<br>"; // Debugging output
    }

    echo "Step 9: Transaction committed. Redirecting...<br>"; // Debugging output

    // Redirect to success page
    header("Location: suksess.php?order_id=$orderId");
    exit;

} catch (Exception $e) {
    $conn->rollback();
    $gopayConn->rollback();
    echo "Error: " . $e->getMessage(); // Debugging output
    exit;
}
?>
