<?php
// Pastikan session sudah dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Periksa apakah user_id ada di sesi
if (!isset($_SESSION['user_id'])) {
    die("User not logged in.");
}

$userId = $_SESSION['user_id'];

// Koneksi ke database
$conn = new mysqli('localhost', 'root', '', 'alfagift');

// Periksa koneksi database
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query untuk mendapatkan semua stamp dari pengguna
$stampQuery = "SELECT * FROM stamp WHERE user_id = ?";
$stmt = $conn->prepare($stampQuery);

if (!$stmt) {
    die("Failed to prepare statement: " . $conn->error);
}

$stmt->bind_param("i", $userId);
$stmt->execute();
$stampResult = $stmt->get_result();

// Menampilkan data stamp
$stamps = [];
if ($stampResult && $stampResult->num_rows > 0) {
    while ($row = $stampResult->fetch_assoc()) {
        $stamps[] = $row;
    }
}
// Initialize total items for badge
$totalItems = 0;
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Use $conn instead of $connection
    $stmt = $conn->prepare("SELECT COUNT(DISTINCT product_id) AS total FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result) {
        $row = $result->fetch_assoc();
        $totalItems = isset($row['total']) ? (int)$row['total'] : 0;
    } else {
        $totalItems = 0;
    }
    
    $stmt->close();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Stamps - Alfagift</title>
    <link rel="stylesheet" href="stamp.css">
</head>

<body>
    <!-- Header -->
    <header>
        <div class="top-bar">
            <div class="social-media">
                <a href="#"><img src="faceb.png" alt="Facebook"></a>
                <a href="#"><img src="twit.png" alt="Twitter"></a>
                <a href="#"><img src="youtube.png" alt="YouTube"></a>
                <a href="#"><img src="instag.png" alt="Instagram"></a>
            </div>
            <div class="language">
            <a href="history.php" class="order-tracking">Order History</a>
                <span>Help</span>
                <div class="dropdown">
                    <img src="US.png" alt="US Flag" class="flag">
                    <select class='bhs'>
                        <option>English (US)</option>
                        <option>Indonesia</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="main-header">
            <img src="alfagift.png" alt="Alfagift Logo" class="logo">
            <div class="search-bar">
                <input type="text" placeholder="Search something...">
                <select>
                    <option>All Categories</option>
                </select>
                <button class='search'><img src="Search.png" alt="Search Icon"></button>
            </div>
            <nav>
                <a href="cart.php" class='cart'>
                    <img src="cart.png" alt="Cart">
                    <span class="badge">0</span>
                </a>
                <a href="#"><img src="love.png" alt="Wishlist"></a>
                <a href="#" class="account-section">
                    <img src="account.png" alt="Account" class='account'>
                    <div>
                        <?php if (isset($_SESSION['user_email'])): ?>
                            <span class="account-text">Welcome, <?= htmlspecialchars($_SESSION['user_email']) ?></span>
                        <?php else: ?>
                            <span class="join-text">Join Alfagift</span>
                            <span class="account-text">My Account</span>
                        <?php endif; ?>
                    </div>
                </a>
            </nav>
        </div>
    </header>

    <main>
    <h1>Your Stamps</h1>

<?php if (!empty($stamps)): ?>
    <ul class="stamp-list">
        <?php foreach ($stamps as $index => $stamp): ?>
            <li>
                <img src="iyaa.png" alt="Stamp Icon" class="stamp-icon">
                <span class="stamp-description">Stamp <?= $index + 1 ?>:</span>
                <?= htmlspecialchars($stamp['description']) ?>
                <span>(Order ID: <?= htmlspecialchars($stamp['order_id']) ?>)</span>
            </li>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <div class="no-stamps">
        <p>Stamp kamu masih kosong. Ayo mulai belanja di Alfagift untuk mendapatkan stamp!</p>
    </div>
<?php endif; ?>
</main>

    <!-- Footer -->
    <footer>
        <div class="footer-container">
            <div class="logo-section">
                <img src="alfagift.png" alt="Logo" class="logo">
            </div>
            <div class="menu-section">
                <div class="menu-column">
                    <h4>First Menu</h4>
                    <ul>
                        <li>Features</li>
                        <li>Enterprise</li>
                        <li>Security</li>
                        <li>Customer Stories</li>
                        <li>Pricing</li>
                        <li>Demo</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Second Menu</h4>
                    <ul>
                        <li>Engineering</li>
                        <li>Financial Services</li>
                        <li>Sales</li>
                        <li>IT</li>
                        <li>Customer Support</li>
                        <li>Human Resources</li>
                        <li>Media</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Third Menu</h4>
                    <ul>
                        <li>Tips</li>
                        <li>Blog</li>
                        <li>Event</li>
                        <li>Certified Program</li>
                        <li>Help Center</li>
                        <li>API</li>
                        <li>Download Template</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Fourth Menu</h4>
                    <ul>
                        <li>About Us</li>
                        <li>Leadership</li>
                        <li>News</li>
                        <li>Media Kit</li>
                        <li>Career</li>
                        <li>Documentation</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Alfagift &copy; 2020. All rights reserved</p>
            <div class="social-media">
                <span>FB</span>
                <span>TW</span>
                <span>LN</span>
                <span>IG</span>
                <span>GH</span>
            </div>
        </div>
    </footer>
</body>

</html>
