document.addEventListener("DOMContentLoaded", () => {
    const cartItems = document.querySelectorAll(".cart-item");

    cartItems.forEach((item) => {
        const minusBtn = item.querySelector(".quantity-btn.minus");
        const plusBtn = item.querySelector(".quantity-btn.plus");
        const quantityInput = item.querySelector(".quantity-input");

        // Event untuk tombol minus
        minusBtn.addEventListener("click", () => {
            let quantity = parseInt(quantityInput.value, 10) || 1; // Pastikan quantity memiliki nilai numerik
            if (quantity > 1) {
                quantity -= 1; // Kurangi 1
                quantityInput.value = quantity; // Update nilai input
                updateQuantity(item.dataset.itemId, quantity); // Panggil server untuk update
            }
        });

        // Event untuk tombol plus
        plusBtn.addEventListener("click", () => {
            let quantity = parseInt(quantityInput.value, 10) || 1; // Pastikan quantity memiliki nilai numerik
            quantity += 1; // Tambahkan 1
            quantityInput.value = quantity; // Update nilai input
            updateQuantity(item.dataset.itemId, quantity); // Panggil server untuk update
        });

        // Event untuk perubahan manual di input
        quantityInput.addEventListener("change", () => {
            let quantity = parseInt(quantityInput.value, 10); // Parse angka dengan basis 10
            if (!isNaN(quantity) && quantity >= 1) {
                quantityInput.value = quantity; // Pastikan nilai tetap valid
                updateQuantity(item.dataset.itemId, quantity); // Panggil server untuk update
            } else {
                quantityInput.value = 1; // Set nilai minimum jika input tidak valid
                updateQuantity(item.dataset.itemId, 1); // Pastikan server juga diupdate ke 1
            }
        });
    });
});

// Fungsi untuk mengupdate quantity ke server
function updateQuantity(itemId, quantity) {
    console.log("Updating quantity for item ID:", itemId, "to:", quantity);

    fetch("update_cart.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ itemId, quantity }),
    })
        .then((response) => response.json())
        .then((data) => {
            if (data.success) {
                console.log("Quantity updated successfully for item ID:", itemId);
            } else {
                console.error("Failed to update quantity:", data.error);
            }
        })
        .catch((error) => console.error("Error:", error));
}


function submitCartForm() {
    const cartItems = [];
    document.querySelectorAll('.cart-item').forEach((item) => {
        const itemData = {
            id: item.dataset.itemId,
            name: item.querySelector('.product-details h2').textContent.trim(),
            price: parseFloat(
                item.querySelector('.product-price p').textContent.replace('Rp', '').replace(/\./g, '').trim()
            ),
            quantity: parseInt(item.querySelector('.quantity-input').value),
            image: item.querySelector('.product-image').getAttribute('src')
        };
        cartItems.push(itemData);
    });

    // Kirim data dalam format JSON ke input hidden
    document.getElementById('cartDataInput').value = JSON.stringify(cartItems);

    // Submit form
    document.getElementById('cartForm').submit();
}
