<?php
$servername = "localhost";
$username = "root"; // or your MySQL username
$password = ""; // or your MySQL password
$dbname = "gopay"; // your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phone = $_POST['phone'];
    $saldo_amount = $_POST['saldo_amount'];

    // Check if phone number and saldo amount are valid
    if (is_numeric($saldo_amount) && $saldo_amount > 0) {
        // First, check if the phone number already exists in the database
        $sql = "SELECT balance FROM saldo WHERE phone = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $phone);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows > 0) {
            // Phone number exists, update the balance by adding the saldo_amount
            $stmt->close(); // Close the previous statement
            $sql = "UPDATE saldo SET balance = balance + ? WHERE phone = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ds", $saldo_amount, $phone);
            if ($stmt->execute()) {
                // Get the updated balance
                $sql = "SELECT balance FROM saldo WHERE phone = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $phone);
                $stmt->execute();
                $stmt->bind_result($new_balance);
                $stmt->fetch();
                
                // Send the success response with the updated balance
                $response['success'] = true;
                $response['new_balance'] = $new_balance;
            } else {
                $response['success'] = false;
                $response['message'] = 'Gagal menambah saldo';
            }
        } else {
            // Phone number doesn't exist, insert a new record
            $stmt->close(); // Close the previous statement
            $sql = "INSERT INTO saldo (phone, balance) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sd", $phone, $saldo_amount);
            if ($stmt->execute()) {
                // Send the success response with the new balance
                $response['success'] = true;
                $response['new_balance'] = $saldo_amount;
            } else {
                $response['success'] = false;
                $response['message'] = 'Gagal menambah saldo';
            }
        }

        $stmt->close();
    } else {
        $response['success'] = false;
        $response['message'] = 'Jumlah saldo tidak valid';
    }
}

$conn->close();

// Return JSON response
echo json_encode($response);
?>
