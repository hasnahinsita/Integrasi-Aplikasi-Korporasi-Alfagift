document.querySelectorAll('.increase-btn').forEach(button => {
    button.addEventListener('click', function() {
        let qtyElement = this.previousElementSibling;
        let currentQty = parseInt(qtyElement.innerText);
        qtyElement.innerText = currentQty + 1;
    });
});

document.querySelectorAll('.decrease-btn').forEach(button => {
    button.addEventListener('click', function() {
        let qtyElement = this.nextElementSibling;
        let currentQty = parseInt(qtyElement.innerText);
        if (currentQty > 1) {
            qtyElement.innerText = currentQty - 1;
        }
    });
});

document.querySelector('.continue-btn').addEventListener('click', function(event) {
    event.preventDefault();  // Mencegah form untuk submit

    // Ambil data produk dari keranjang (cart)
    const cartItems = document.querySelectorAll('.cart-item');
    const subtotal = calculateSubtotal(cartItems);
    const tax = subtotal * 0.025; // 2.5% tax
    const shipping = 10000; // Biaya pengiriman tetap
    const discount = subtotal * 0.05; // 5% diskon

    // Menghitung total
    const total = subtotal + tax + shipping - discount;

    // Update Order Summary
    document.querySelector('.order-items').innerHTML = generateOrderSummary(cartItems);
    document.querySelector('#subtotal').textContent = `Rp ${formatCurrency(subtotal)}`;
    document.querySelector('#total').textContent = `Rp ${formatCurrency(total)}`;

    // Tampilkan order summary dari kanan
    document.getElementById('order-summary').style.display = 'block';
    document.querySelector('.left-column').style.display = 'none';  // Menyembunyikan kolom kiri jika diperlukan
});

// Fungsi untuk menghitung subtotal
function calculateSubtotal(cartItems) {
    let subtotal = 0;
    cartItems.forEach(function(item) {
        const price = parseFloat(item.querySelector('.product-details p').textContent.replace('Rp ', '').replace(',', '.'));
        const qty = parseInt(item.querySelector('.quantity p').textContent);
        subtotal += price * qty;
    });
    return subtotal;
}

// Fungsi untuk format mata uang
function formatCurrency(amount) {
    return amount.toLocaleString('id-ID', { style: 'currency', currency: 'IDR' }).replace('IDR', '');
}

// Fungsi untuk membuat daftar ringkasan pesanan
function generateOrderSummary(cartItems) {
    let summaryHTML = '';
    cartItems.forEach(function(item) {
        const productName = item.querySelector('.product-details h4').textContent;
        const productPrice = item.querySelector('.product-details p').textContent;
        const qty = item.querySelector('.quantity p').textContent;
        const imageSrc = item.querySelector('.product-image').src;

        summaryHTML += `
            <div class="order-item">
                <img src="${imageSrc}" alt="${productName}" class="product-image">
                <div class="product-details">
                    <h4>${productName}</h4>
                    <div class="product-price-and-quantity">
                        <p>${productPrice}</p>
                        <p>Item Ordered: ${qty}</p>
                    </div>
                </div>
            </div>
        `;
    });
    return summaryHTML;
}



    document.getElementById('continue-btn').addEventListener('click', function(event) {
        // Ambil data input dari form Customer Information
        const firstName = document.getElementById('first-name').value.trim();
        const lastName = document.getElementById('last-name').value.trim();
        const email = document.getElementById('email').value.trim();
        const phone = document.getElementById('phone').value.trim();
        const address = document.getElementById('address').value.trim();

        // Validasi apakah semua field terisi
        if (!firstName || !lastName || !email || !phone || !address) {
            alert('Please fill out all customer information fields before continuing to shipping.');
        } else {
            // Data valid, submit form
            document.getElementById('customer-form').submit();
        }
    });




    document.getElementById('customer-form').addEventListener('submit', function(event) {
        // Cek apakah semua field terisi
        const form = this;
        const inputs = form.querySelectorAll('input, textarea');
        let valid = true;

        inputs.forEach(input => {
            if (!input.value.trim()) {
                valid = false;
                input.style.border = '1px solid red'; // Beri indikator visual
            } else {
                input.style.border = ''; // Hapus indikator jika valid
            }
        });

        if (!valid) {
            alert('Please fill out all required fields.');
            event.preventDefault(); // Batalkan pengiriman form jika tidak valid
        }
    });


