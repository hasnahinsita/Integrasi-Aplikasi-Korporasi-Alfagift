
function loadStoreData(storeId) {
    // Kirim permintaan AJAX untuk mendapatkan data promo dan produk
    fetch(`getStoreData.php?store_id=${storeId}`)
        .then(response => response.json())
        .then(data => {
            // Update promo
            const promoContainer = document.querySelector('.promo-images');
            promoContainer.innerHTML = ''; // Hapus konten lama
            data.promos.forEach(promo => {
                const promoCard = document.createElement('div');
                promoCard.classList.add('promo-card');
                promoCard.innerHTML = `<img src="../admin/${promo.image_path}" alt="Promo Image">`;
                promoContainer.appendChild(promoCard);
            });

            // Update produk
            const productContainer = document.querySelector('.products');
            productContainer.innerHTML = ''; // Hapus konten lama
            data.products.forEach(product => {
                const productCard = document.createElement('div');
                productCard.classList.add('card');
                productCard.innerHTML = `
                    <img src="../admin/${product.image_path}" alt="${product.name}">
                    <h2>${product.name}</h2>
                    <p>Rp ${Number(product.price).toLocaleString('id-ID')}</p>
                `;
                productContainer.appendChild(productCard);
            });
        })
        .catch(error => console.error('Error loading store data:', error));
}

    document.addEventListener("DOMContentLoaded", function () {
        const promoCards = document.querySelectorAll(".promo-card");

        // Fungsi untuk mengecek apakah elemen terlihat di viewport
        function isElementInViewport(el) {
            const rect = el.getBoundingClientRect();
            return (
                rect.top >= 0 &&
                rect.left >= 0 &&
                rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.right <= (window.innerWidth || document.documentElement.clientWidth)
            );
        }

        // Fungsi untuk menambahkan kelas visible jika elemen terlihat
        function checkVisibility() {
            promoCards.forEach((card) => {
                if (isElementInViewport(card)) {
                    card.classList.add("visible");
                }
            });
        }

        // Jalankan fungsi saat scroll atau pertama kali halaman dimuat
        window.addEventListener("scroll", checkVisibility);
        checkVisibility();
    });


    document.addEventListener("DOMContentLoaded", function () {
        const productCards = document.querySelectorAll(".card");

        // Fungsi untuk mengecek apakah elemen terlihat di viewport
        function isElementInViewport(el) {
            const rect = el.getBoundingClientRect();
            return (
                rect.top <= (window.innerHeight || document.documentElement.clientHeight) &&
                rect.bottom >= 0
            );
        }

        // Fungsi untuk menambahkan atau menghapus kelas visible
        function checkVisibility() {
            productCards.forEach((card) => {
                if (isElementInViewport(card)) {
                    card.classList.add("visible");
                } else {
                    card.classList.remove("visible"); // Hapus jika elemen keluar dari viewport
                }
            });
        }

        // Event listener untuk scroll dan resize
        window.addEventListener("scroll", checkVisibility);
        window.addEventListener("resize", checkVisibility);

        // Jalankan sekali saat halaman pertama kali dimuat
        checkVisibility();
    });

    document.addEventListener("DOMContentLoaded", () => {
        const elements = document.querySelectorAll(
            ".promo-card, .card, .benefit-item, .text-section, .image-section"
        );
    
        let lastScrollTop = 0;
    
        const observer = new IntersectionObserver(
            (entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting) {
                        const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
                        // Tambahkan arah animasi berdasarkan arah scroll
                        if (scrollTop > lastScrollTop) {
                            // Scroll ke bawah
                            entry.target.classList.add("visible");
                            entry.target.classList.remove("scroll-up");
                        } else {
                            // Scroll ke atas
                            entry.target.classList.add("scroll-up");
                            entry.target.classList.remove("visible");
                        }
    
                        lastScrollTop = scrollTop <= 0 ? 0 : scrollTop; // Pastikan nilai tidak negatif
                    }
                });
            },
            {
                threshold: 0.1,
            }
        );
    
        // Observasi elemen-elemen
        elements.forEach((element) => {
            observer.observe(element);
        });
    });
    