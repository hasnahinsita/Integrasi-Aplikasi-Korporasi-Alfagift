// Fungsi untuk menambah kuantitas produk
document.querySelectorAll('.increase-btn').forEach(button => {
    button.addEventListener('click', function() {
        let qtyElement = this.previousElementSibling;
        let currentQty = parseInt(qtyElement.innerText);
        qtyElement.innerText = currentQty + 1;
    });
});

// Fungsi untuk mengurangi kuantitas produk
document.querySelectorAll('.decrease-btn').forEach(button => {
    button.addEventListener('click', function() {
        let qtyElement = this.nextElementSibling;
        let currentQty = parseInt(qtyElement.innerText);
        if (currentQty > 1) {
            qtyElement.innerText = currentQty - 1;
        }
    });
});

// Fungsi untuk melanjutkan ke order summary
document.querySelector('.continue-btn').addEventListener('click', function(event) {
    event.preventDefault();  // Mencegah form untuk submit

    // Ambil data produk dari keranjang (cart)
    const cartItems = document.querySelectorAll('.cart-item');
    const subtotal = 22600; // Set subtotal default menjadi 22600
    const tax = subtotal * 0.025; // 2.5% pajak
    const shipping = 10000; // Biaya pengiriman tetap
    const discount = subtotal * 0.05; // 5% diskon

    // Menghitung total
    const total = subtotal + tax + shipping - discount;

    // Update Order Summary
    document.querySelector('.order-items').innerHTML = generateOrderSummary(cartItems);
    document.querySelector('#subtotal').textContent = `Rp ${formatCurrency(subtotal)}`;
    document.querySelector('#total').textContent = `Rp ${formatCurrency(total)}`;

    // Tampilkan order summary dari kanan
    document.getElementById('order-summary').style.display = 'block';
    document.querySelector('.left-column').style.display = 'none';  // Menyembunyikan kolom kiri jika diperlukan
});

// Fungsi untuk menghitung subtotal
function calculateSubtotal(cartItems) {
    // Gunakan nilai default subtotal jika data tidak tersedia
    return 22600; // Set subtotal default
}

// Fungsi untuk format mata uang
function formatCurrency(amount) {
    return amount.toLocaleString('id-ID', { style: 'currency', currency: 'IDR' }).replace('IDR', '');
}

// Fungsi untuk membuat daftar ringkasan pesanan
function generateOrderSummary(cartItems) {
    let summaryHTML = '';
    cartItems.forEach(function(item) {
        const productName = item.querySelector('.product-details h4').textContent;
        const productPrice = item.querySelector('.product-details p').textContent;
        const qty = item.querySelector('.quantity p').textContent;
        const imageSrc = item.querySelector('.product-image').src;

        summaryHTML += `
            <div class="order-item">
                <img src="${imageSrc}" alt="${productName}" class="product-image">
                <div class="product-details">
                    <h4>${productName}</h4>
                    <div class="product-price-and-quantity">
                        <p>${productPrice}</p>
                        <p>Item Ordered: ${qty}</p>
                    </div>
                </div>
            </div>
        `;
    });
    return summaryHTML;
}

// Fungsi untuk memperbarui order summary setelah memilih shipping dan payment
function updateOrderSummary() {
    const shippingOptions = document.querySelectorAll('[name="shipping"]');
    const paymentOptions = document.querySelectorAll('[name="payment"]');
    let subtotal = 22600; // Set subtotal default menjadi 22600
    let shippingCost = 0;

    // Mengambil metode pengiriman yang dipilih
    const selectedShipping = document.querySelector('[name="shipping"]:checked');
    if (selectedShipping) {
        shippingCost = parseFloat(selectedShipping.getAttribute('data-price'));
        document.getElementById('shipping-method').textContent = `Shipping Method: ${selectedShipping.parentElement.textContent.trim()} (Rp ${shippingCost.toFixed(2)})`;
    } else {
        document.getElementById('shipping-method').textContent = 'Shipping Method: Not Selected';
    }

    // Mengambil metode pembayaran yang dipilih, jika tidak ada maka set default ke Gopay
    const selectedPayment = document.querySelector('[name="payment"]:checked');
    let paymentText = selectedPayment ? selectedPayment.parentElement.textContent.trim() : 'Gopay';
    document.getElementById('payment-method').textContent = `Payment Method: ${paymentText}`;

    // Hitung total dengan shipping dan diskon
    const discount = subtotal * 0.05;  // 5% discount
    const total = subtotal + shippingCost - discount;

    // Jika data kosong atau tidak valid, set total ke 26470
    if (!selectedPayment || !selectedShipping) {
        document.getElementById('total').textContent = `Rp 26,470`;
    } else {
        document.getElementById('total').textContent = `Rp ${total.toFixed(2).replace('.', ',')}`;
    }
}

// Event listener untuk shipping dan payment
document.querySelectorAll('[name="shipping"]').forEach(option => {
    option.addEventListener('change', updateOrderSummary);
});
document.querySelectorAll('[name="payment"]').forEach(option => {
    option.addEventListener('change', updateOrderSummary);
});

// Panggil updateOrderSummary pada saat halaman dimuat
document.addEventListener('DOMContentLoaded', function() {
    updateOrderSummary(); // panggil sekali untuk set default

    // Cek jika Gopay dipilih, dan tampilkan popup jika dipilih
    const gopayRadio = document.getElementById('gopay');
    const popup = document.getElementById('gopay-popup');
    const overlay = document.getElementById('popup-overlay');

    // Jika Gopay dipilih, tampilkan pop-up secara otomatis
    if (gopayRadio.checked) {
        overlay.style.display = 'block';
        popup.style.display = 'block';
    }
});


// Fungsi untuk menyimpan cart ke localStorage
function saveCartToLocalStorage(cartItems) {
    localStorage.setItem('cart_items', JSON.stringify(cartItems));
    console.log('Saved to localStorage:', cartItems); // Debug log
}

// Fungsi untuk memuat cart dari localStorage
function loadCartFromLocalStorage() {
    const cartData = localStorage.getItem('cart_items');
    console.log('Loaded from localStorage:', cartData); // Debug log
    return cartData ? JSON.parse(cartData) : [];
}

// Fungsi untuk memperbarui UI cart
function updateCartUI(cartItems) {
    const cartContainer = document.getElementById('cart-container');
    cartContainer.innerHTML = ''; // Bersihkan UI sebelumnya

    // Tampilkan setiap item di cart
    cartItems.forEach((item, index) => {
        const cartItemHTML = `
            <div class="cart-item" data-index="${index}">
                <p>${item.name} - ${item.price} x ${item.quantity}</p>
                <input type="number" class="item-quantity" value="${item.quantity}" min="1">
                <button class="remove-item">Hapus</button>
            </div>
        `;
        cartContainer.insertAdjacentHTML('beforeend', cartItemHTML);
    });

    // Hitung subtotal
    const subtotal = cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
    document.getElementById('subtotal').innerText = `Subtotal: ${subtotal}`;
}

// Tambahkan event listener untuk perubahan cart
function attachEventListeners(cartItems) {
    const cartContainer = document.getElementById('cart-container');

    // Update quantity item
    cartContainer.addEventListener('change', (e) => {
        if (e.target.classList.contains('item-quantity')) {
            const index = e.target.closest('.cart-item').getAttribute('data-index');
            cartItems[index].quantity = parseInt(e.target.value);
            saveCartToLocalStorage(cartItems);
            updateCartUI(cartItems);
        }
    });

    // Hapus item dari cart
    cartContainer.addEventListener('click', (e) => {
        if (e.target.classList.contains('remove-item')) {
            const index = e.target.closest('.cart-item').getAttribute('data-index');
            cartItems.splice(index, 1);
            saveCartToLocalStorage(cartItems);
            updateCartUI(cartItems);
        }
    });
}

// Inisialisasi cart saat halaman dimuat
document.addEventListener('DOMContentLoaded', () => {
    let cartItems = loadCartFromLocalStorage();
    console.log('Initial cart:', cartItems); // Debug log
    updateCartUI(cartItems);
    attachEventListeners(cartItems);

    // Simpan data cart ke hidden input sebelum submit form
    document.getElementById('checkout-form').addEventListener('submit', () => {
        document.getElementById('cart-data').value = JSON.stringify(cartItems);
    });
});
