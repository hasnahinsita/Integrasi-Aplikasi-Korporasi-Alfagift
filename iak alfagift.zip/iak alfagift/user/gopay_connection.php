<?php
$gopayConn = new mysqli('localhost', 'root', '', 'gopay');

// Debugging output untuk koneksi ke database GoPay
if ($gopayConn->connect_error) {
    die("Connection failed: " . $gopayConn->connect_error);
} else {
    echo "Connected to GoPay database successfully.<br>"; // Debugging output
}

?>
