<?php
// Database connection
$host = 'localhost';
$dbname = 'alfagift';
$username = 'root';
$password = ''; // Add your password if needed

$conn = new mysqli($host, $username, $password, $dbname);

// Check database connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query for store list
$storeResult = $conn->query("SELECT * FROM stores");

// Query promotions for the second store
$promoQuery = "SELECT * FROM promotions WHERE store_id = 2";
$promoResult = $conn->query($promoQuery);

// Query products for the second store
$productQuery = "SELECT * FROM products WHERE store_id = 2";
$productResult = $conn->query($productQuery);

// Handle promo results
$images = [];
if ($promoResult && $promoResult->num_rows > 0) {
    while ($row = $promoResult->fetch_assoc()) {
        $images[] = $row['image_path'];
    }
}

// Handle product results
$products = [];
if ($productResult && $productResult->num_rows > 0) {
    while ($row = $productResult->fetch_assoc()) {
        $products[] = $row;
    }
}

// Handle authentication
include 'auth.php';
if (!isLoggedIn()) {
    $userEmail = null;
} else {
    $userEmail = $_SESSION['user_email'];
}

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];
} else {
    header('Location: sign in.php');
    exit;
}

$_SESSION['user_email'] = $user['email'];

// Initialize total items for badge
$totalItems = 0;
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Use $conn instead of $connection
    $stmt = $conn->prepare("SELECT COUNT(DISTINCT product_id) AS total FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result) {
        $row = $result->fetch_assoc();
        $totalItems = isset($row['total']) ? (int)$row['total'] : 0;
    } else {
        $totalItems = 0;
    }
    
    $stmt->close();
}

// Query untuk menghitung jumlah stamp untuk pengguna yang sedang login
$userId = $_SESSION['user_id']; // Pastikan user sudah login dan ada session user_id
$stampQuery = "SELECT COUNT(*) AS total_stamps FROM stamp WHERE user_id = ?";
$stmt = $conn->prepare($stampQuery);
$stmt->bind_param("i", $userId);
$stmt->execute();
$stampResult = $stmt->get_result();

$stampCount = 0;
if ($stampResult && $stampResult->num_rows > 0) {
    $row = $stampResult->fetch_assoc();
    $stampCount = $row['total_stamps'];
}
$stmt->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Alfagift</title>
    <link rel="stylesheet" href="hometelang.css">
</head>

<body>
    <!-- Header -->
    <header>
        <div class="top-bar">
            <div class="social-media">
                <a href="#" class='fb'><img src="faceb.png" alt="Facebook"></a>
                <a href="#"><img src="twit.png" alt="Twitter"></a>
                <a href="#"><img src="youtube.png" alt="YouTube"></a>
                <a href="#"><img src="instag.png" alt="Instagram"></a>
            </div>
            <div class="language">
                <span>Order tracking</span>
                <span>Help</span>
                <div class="dropdown">
                    <img src="US.png" alt="US Flag" class="flag">
                    <select class='bhs'>
                        <option>English (US)</option>
                        <option>Indonesia</option>
                    </select>
                </div>
            </div>

        </div>
        <div class="main-header">

            <img src="alfagift.png" alt="Alfagift Logo" class="logo">
            <div class="search-bar">

                <input type="text" placeholder="Search something...">
               
            </div>
            <nav>
                <div class="delivery-options">
                           <!-- Tombol Stamp -->
    <a id="stamp-btn" class="button" href="stamp_page.php">
        <i class="icon-stamp">🏷️</i> Banyak Stamp (<?= $stampCount ?>)
    </a>
                    <!-- Tombol Pengantaran -->
                    <a id="delivery-btn" class="button" href="homelogin.php">
                        <i class="icon-delivery">🚚</i> Pengantaran
                    </a>

                    <!-- Tombol Pickup -->
                    <div class="pickup-container">
                        <button id="pickup-btn" class="button active" onclick="togglePickupDropdown()">
                            <i class="icon-pickup">🛍️</i> Pickup
                        </button>

                        <!-- Dropdown untuk Pickup -->
                        <div id="pickup-dropdown" class="dropdown">
                            <a href="homekamal.php"><i>🏪</i> Alfamart Kamal</a>
                            <a href="hometelang.php"><i>🏪</i> Alfamart Telang</a>
                        </div>
                    </div>
                </div>


                <nav>
                <a href="cartkamal.php" class='cart'>
    <img src="cart.png" alt="Cart">
    <!-- Menampilkan badge jumlah item -->
    <span class="badge"><?php echo $totalItems; ?></span>
</a>
                    <a href="#" class='love'><img src="love.png" alt="Wishlist"></a>
                    <a href="#" class="account-section">
                        <img src="account.png" alt="Account" class='account'>
                        <div>
                            <?php if (isset($_SESSION['user_email'])): ?>
                                <span class="account-text"><?= htmlspecialchars($_SESSION['user_email']) ?></span>
                            <?php else: ?>
                                <span class="join-text">Join Alfagift</span>
                                <span class="account-text">My Account</span>
                            <?php endif; ?>
                        </div>
                    </a>
                </nav>

        </div>
    </header>

    <div class="container">
        <div class="text-section">
            <h4>DAILY ALFAGIFT</h4>
            <h1>Convenient Shopping & Fast Delivery</h1>
            <p>Nikmati kemudahan belanja dengan pengiriman cepat dan terpercaya. Belanja kebutuhan Anda kapan saja, di mana saja dengan layanan AlfaGift.</p>
            <div class="buttons">
                <button class="buy-button">Shop Now</button>
                <button class="learn-more-button">Learn More</button>
            </div>
        </div>
        <div class="image-section">
            <img src="001.png" alt="Bee on a Scooter">
        </div>
    </div>
    <div class="pickup-delivery-container">
        <button class="option-button" id="pickup-btn" onclick="togglePickupDelivery('pickup')">Ambil di Toko</button>
        <button class="option-button" id="delivery-btn" onclick="togglePickupDelivery('delivery')">Pengantaran</button>
    </div>




    <div class="category-container">
        <div class="category-header">
            <h2>Category</h2>
            <button class="view-all-button">View All</button>
        </div>
        <div class="category-items">
            <div class="category-item">
                <img src="food.png" alt="Makanan">
                <p>Makanan</p>
            </div>
            <div class="category-item">
                <img src="drink.png" alt="Minuman">
                <p>Minuman</p>
            </div>
            <div class="category-item">
                <img src="mother.png" alt="Kebutuhan Ibu dan Anak">
                <p>Kebutuhan Ibu dan Anak</p>
            </div>
            <div class="category-item">
                <img src="cat.png" alt="Pet Foods">
                <p>Pet Foods</p>
            </div>
            <div class="category-item">
                <img src="spoon.png" alt="Kebutuhan Dapur">
                <p>Kebutuhan Dapur</p>
            </div>
            <div class="category-item">
                <img src="obat.png" alt="Kebutuhan Kesehatan">
                <p>Kebutuhan Kesehatan</p>
            </div>
        </div>
    </div>

    <div class="promo-container">
        <h2>Promo</h2>
        <p>Temukan banyak promo menarik hanya di Alfagift</p>

        <div class="promo-images-container">
            <?php
            // Query promo menggunakan mysqli
            $promoResult = $conn->query("SELECT * FROM promotions");

            if ($promoResult && $promoResult->num_rows > 0) {
                $images = [];
                while ($row = $promoResult->fetch_assoc()) {
                    $images[] = $row['image_path'];
                }
            } else {
                $images = []; // Jika tidak ada data promo
                echo "<p>No promotions available.</p>";
            }
            ?>

            <div class="promo-images">
                <?php foreach ($images as $index => $image): ?>
                    <?php
                    // Correct the image path here
                    $imagePath = "../admin/" . htmlspecialchars($image);
                    echo "<!-- Image path: $imagePath -->"; // For debugging
                    ?>
                    <div class="promo-card" style="display: <?= $index < 2 ? 'block' : 'none'; ?>">
                        <img src="../admin/<?= htmlspecialchars($image) ?>" alt="Promo Image">


                    </div>
                <?php endforeach; ?>
            </div>

        </div>

        <div class="product-container">
            <h1>Best Seller Products</h1>
            <p>Check out our best seller products on Elma website right now</p>
            <div class="products">
                <?php if (!empty($products)): ?>
                    <?php foreach ($products as $product): ?>
                        <div class="card">
                            <a href="productkamal.php?id=<?= htmlspecialchars($product['id']) ?>&name=<?= urlencode($product['name']) ?>&price=<?= urlencode($product['price']) ?>&image=<?= urlencode($product['image_path']) ?>">
                                <img src="../admin/<?= htmlspecialchars($product['image_path']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
                                <div class="description"><?= htmlspecialchars($product['description']) ?></div> <!-- Deskripsi -->
                                <h2><?= htmlspecialchars($product['name']) ?></h2> <!-- Nama barang -->
                                <div class="price-star">
                                    <p>Rp <?= number_format($product['price'], 0, ',', '.') ?></p> <!-- Harga -->
                                    <div class="stars">
                                        <?php for ($i = 0; $i < 5; $i++): ?> <!-- Bintang -->
                                            <span>★</span>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No products available.</p>
                <?php endif; ?>
            </div>


        </div>

    </div>



    </div>

    </div>

    <div class="alfagift-benefits">
        <h1>Yuk belanja di Alfagift dan Dapatkan Keuntungannya!</h1>
        <p>Check our latest article to get meaningful content or tips for shopping</p>
        <div class="benefit-items">
            <div class="benefit-item">
                <img src="ongkir.png" alt="Gratis Ongkir">
                <h3>Gratis Ongkir Tanpa Syarat</h3>
                <p>Belanja berapa pun, gratis biaya pengiriman tanpa batas maksimal</p>
            </div>
            <div class="benefit-item">
                <img src="delivery.png" alt="Sameday Delivery">
                <h3>Sameday Delivery</h3>
                <p>Pesanan diantar lebih cepat karena diantar dari toko Alfamart terdekat</p>
            </div>
            <div class="benefit-item">
                <img src="poin.png" alt="Poin Terintegrasi">
                <h3>Poin Terintegrasi</h3>
                <p>Dapatkan poin untuk setiap pembelanjaan di Alfagift atau toko Alfamart</p>
            </div>
            <div class="benefit-item">
                <img src="produklengkap.png" alt="Produk Lebih Lengkap">
                <h3>Produk Lebih Lengkap</h3>
                <p>Lebih lengkap dengan produk premium, kemasan besar, dan kebutuhan lainnya</p>
            </div>
        </div>
    </div>
    <script src="hometelang.js"></script>


    <!-- 
    ini footer -->
    <footer>
        <div class="footer-container">
            <div class="logo-section">
                <img src="alfagift.png" alt="Logo" class="logo">
            </div>
            <div class="menu-section">
                <div class="menu-column">
                    <h4>First Menu</h4>
                    <ul>
                        <li>Features</li>
                        <li>Enterprise</li>
                        <li>Security</li>
                        <li>Customer Stories</li>
                        <li>Pricing</li>
                        <li>Demo</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Second Menu</h4>
                    <ul>
                        <li>Engineering</li>
                        <li>Financial Services</li>
                        <li>Sales</li>
                        <li>IT</li>
                        <li>Customer Support</li>
                        <li>Human Resources</li>
                        <li>Media</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Third Menu</h4>
                    <ul>
                        <li>Tips</li>
                        <li>Blog</li>
                        <li>Event</li>
                        <li>Certified Program</li>
                        <li>Help Center</li>
                        <li>API</li>
                        <li>Download Template</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Fourth Menu</h4>
                    <ul>
                        <li>About Us</li>
                        <li>Leadership</li>
                        <li>News</li>
                        <li>Media Kit</li>
                        <li>Career</li>
                        <li>Documentation</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Alfagift © Copyright 2020, Inc. All rights reserved</p>
            <div class="social-media">
                <span>FB</span>
                <span>TW</span>
                <span>LN</span>
                <span>IG</span>
                <span>GH</span>
            </div>
        </div>
    </footer>
</body>

</html>