<?php
$host = 'localhost';      // atau IP server database jika berbeda
$user = 'root';           // username untuk database
$password = '';           // password untuk database
$dbname = 'alfagift';     // nama database yang digunakan
$conn = new mysqli($host, $user, $password, $dbname);
// Membuat koneksi

session_start();
if (!isset($_SESSION['user_email'])) {
    // Redirect ke halaman login jika belum login
    header("Location: sign in.php");
    exit;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $userId = $_POST['user_id'] ?? '';
    $firstName = $_POST['first_name'] ?? '';
    $lastName = $_POST['last_name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $address = $_POST['address'] ?? '';

    // Cek apakah ada data yang hilang
    if (!$firstName || !$lastName || !$email || !$phone || !$address) {
        $error = "Please provide all required information.";
    } else {
        // Jika data lengkap, proses data lebih lanjut
    }
}
// Ambil data Order Summary
$cartItems = $_POST['cart_items'] ?? [];
$subtotal = $_POST['subtotal'] ?? 0;


// Menangani pengiriman dan diskon
// $shippingMethod
$paymentMethod = $_POST['payment'] ?? ''; // Mengambil dari form
$totalPrice = $total ?? 0; // Total yang dihitung sebelumnya

// $paymentMethod
$shippingMethod = $_POST['shipping_method'] ?? 'express';
$shippingCost = 0;
$discount = 0.05; // 5% diskon

// Tentukan biaya pengiriman berdasarkan metode
if ($shippingMethod == 'express') {
    $shippingCost = 25000; // Free shipping
} elseif ($shippingMethod == 'regular') {
    $shippingCost = 15000; // Rp 25,000
} elseif ($shippingMethod == 'economy') {
    $shippingCost = 5000; // Rp 15,000
}

// Hitung subtotal setelah diskon
$subtotalAfterDiscount = $subtotal - ($subtotal * $discount);

// Hitung total (subtotal + biaya pengiriman)
$total = $subtotalAfterDiscount + $shippingCost;


$totalItems = 0;
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Query untuk menghitung jumlah total item di keranjang
    $stmt = $conn->prepare("SELECT COUNT(DISTINCT product_id) AS total FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        $row = $result->fetch_assoc();
        $totalItems = isset($row['total']) ? (int)$row['total'] : 0;
    } else {
        $totalItems = 0;
    }

    $stmt->close();
}
$cart_data = $_SESSION['cart_items'] ?? [];


// Ambil cart items dari session
$cart_items = isset($_SESSION['cart_items']) ? $_SESSION['cart_items'] : [];


$productId = isset($_GET['id']) ? $_GET['id'] : '';
$productName = isset($_GET['name']) ? $_GET['name'] : '';
$productPrice = isset($_GET['price']) ? $_GET['price'] : '';
$productImage = isset($_GET['image']) ? $_GET['image'] : '';
$productQty = isset($_GET['qty']) ? $_GET['qty'] : 1;

// Tentukan produk yang akan ditampilkan di cart
$products = [
    [
        'id' => $productId,
        'name' => urldecode($productName),
        'price' => $productPrice,
        'image' => urldecode($productImage),
        'qty' => $productQty,
    ]
];
$totalItems = 0;

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Query untuk menghitung jumlah total item di keranjang
    $stmt = $conn->prepare("SELECT COUNT(DISTINCT product_id) AS total FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        $row = $result->fetch_assoc();
        $totalItems = isset($row['total']) ? (int)$row['total'] : 0;
    } else {
        $totalItems = 0;
    }

    $stmt->close();
}



// Inisialisasi variabel
$cart_items = [];
$subtotal = 0;

// Tangkap data dari POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cart_data'])) {
    $cart_items = json_decode($_POST['cart_data'], true);

    // Hitung subtotal
    foreach ($cart_items as $item) {
        $subtotal += $item['price'] * (isset($item['quantity']) ? $item['quantity'] : 0);
    }
}



$cart_items = isset($_SESSION['cart_items']) ? $_SESSION['cart_items'] : [];

// Memeriksa jika ada data cart_data yang dikirim via POST
if (isset($_POST['cart_data'])) {
    // Mengambil dan meng-decode data JSON
    $cart_items = json_decode($_POST['cart_data'], true);
} else {
    // Jika tidak ada data yang dikirimkan, bisa mengarahkan ke halaman error atau kembali ke cart
    $cart_items = [];
}
// Ambil data customer dari session
$customer_info = $_SESSION['customer_info'] ?? [];
$customer_data = isset($_POST['customer_data']) ? json_decode($_POST['customer_data'], true) : [];


// $phone = $_GET['phone'] ?? '';

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product - Alfagift</title>
    <link rel="stylesheet" href="shipping.css">
</head>

<style>
    /* Pop-up styling */
    .popup {
        display: none;
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: linear-gradient(135deg, #ffffff, #f0f0f0);
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        padding: 30px;
        z-index: 1000;
        border-radius: 12px;
        text-align: center;
        width: 300px;
        font-family: Arial, sans-serif;
    }

    .popup h3 {
        color: #333;
        margin-bottom: 15px;
        font-size: 20px;
    }

    .popup p {
        color: #666;
        font-size: 14px;
        margin-bottom: 20px;
    }

    .popup input {
        width: calc(100% - 20px);
        padding: 10px;
        margin: 10px 0;
        border: 1px solid #ccc;
        border-radius: 6px;
        font-size: 14px;
    }

    .popup .buttons {
        display: flex;
        justify-content: space-around;
    }

    .popup .buttons button {
        background: linear-gradient(135deg, #4caf50, #66bb6a);
        color: white;
        border: none;
        border-radius: 6px;
        padding: 10px 15px;
        cursor: pointer;
        font-size: 14px;
        transition: background 0.3s ease;
    }

    .popup .buttons button:hover {
        background: linear-gradient(135deg, #43a047, #4caf50);
    }

    .popup .buttons #cancel-btn {
        background: linear-gradient(135deg, #f44336, #e57373);
    }

    .popup .buttons #cancel-btn:hover {
        background: linear-gradient(135deg, #d32f2f, #f44336);
    }

    .popup-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.6);
        z-index: 999;
    }
</style>


<body>
    <!-- Header -->
    <header>
        <div class="top-bar">
            <div class="social-media">
                <a href="#" class='fb'><img src="faceb.png" alt="Facebook"></a>
                <a href="#"><img src="twit.png" alt="Twitter"></a>
                <a href="#"><img src="youtube.png" alt="YouTube"></a>
                <a href="#"><img src="instag.png" alt="Instagram"></a>
            </div>
            <div class="language">
                <span>Order tracking</span>
                <span>Help</span>
                <div class="dropdown">
                    <img src="US.png" alt="US Flag" class="flag">
                    <select class='bhs'>
                        <option>English (US)</option>
                        <option>Indonesia</option>
                    </select>
                </div>
            </div>

        </div>
        <div class="main-header">

            <img src="alfagift.png" alt="Alfagift Logo" class="logo">
            <div class="search-bar">

                <input type="text" placeholder="Search something...">
                <select>
                    <option class='opsi'>All Categories</option>
                </select>
                <button class='search'><img src="Search.png" alt="Search Icon"></button>

            </div>
            <nav>
                <a href="cart.php" class='cart'>
                    <img src="cart.png" alt="Cart">
                    <!-- Menampilkan badge jumlah item -->
                    <span class="badge"><?php echo $totalItems; ?></span>
                </a>
                <a href="#" class='cart'><img src="love.png" alt="Wishlist"></a>
                <a href="#" class="account-section">
                    <img src="account.png" alt="Account" class='account'>
                    <div>
                        <?php if (isset($_SESSION['user_email'])): ?>
                            <span class="account-text"><?= htmlspecialchars($_SESSION['user_email']) ?></span>
                        <?php else: ?>
                            <span class="join-text">Join Alfagift</span>
                            <span class="account-text">My Account</span>
                        <?php endif; ?>
                    </div>
                </a>
            </nav>

        </div>
    </header>
    <div class="content">
        <!-- Title Section -->
        <div class="title-section">
            <div class="title-text">
                <h1>Shipping & Payment</h1>
                <p>Fill this form to know who you are. The lovely customer we care about it</p>
            </div>
            <a href="homelogin.php" class="back-button">Back to shopping</a>
        </div>

        <!-- Breadcrumb Section -->
        <div class="breadcrumb">
            <div class="breadcrumb-item-container">
                <span class="breadcrumb-number active">1</span>
                <span class="breadcrumb-item active">Cart</span>
            </div>
            <span class="breadcrumb-separator">→</span>

            <div class="breadcrumb-item-container">
                <span class="breadcrumb-number active">2</span>
                <span class="breadcrumb-item active">Customer Information</span>
            </div>
            <span class="breadcrumb-separator">→</span>

            <div class="breadcrumb-item-container">
                <span class="breadcrumb-number active">3</span>
                <span class="breadcrumb-item active">Shipping & payment</span>
            </div>
            <span class="breadcrumb-separator">→</span>

            <div class="breadcrumb-item-container">
                <span class="breadcrumb-number">4</span>
                <span class="breadcrumb-item">Review</span>
            </div>
        </div>

    </div>
    <div class="container">
        <div class="left-column">
            <div class="shipping-methods">
                <h3>Select Shipping Method</h3>
                <div class="shipping-option">
                    <input type="radio" name="shipping" id="express" value="express" data-price="25000" checked>
                    <label for="express">
                        <div class="shipping-details">
                            <div class="shipping-name">Same Day</div>
                            <div class="shipping-price">Rp 20.000</div>
                            <div class="shipping-description">Fast delivery within 30 minute.</div>
                        </div>
                    </label>
                </div>

                <div class="shipping-option">
                    <input type="radio" name="shipping" id="regular" value="regular" data-price="15000">
                    <label for="regular">
                        <div class="shipping-details">
                            <div class="shipping-name">Reguler</div>
                            <div class="shipping-price">Rp 10.000</div>
                            <div class="shipping-description">Delivery within 1 hour.</div>
                        </div>
                    </label>
                </div>

                <div class="shipping-option">
                    <input type="radio" name="shipping" id="economy" value="economy" data-price="5000">
                    <label for="economy">
                        <div class="shipping-details">
                            <div class="shipping-name">Gratis Ongkir</div>
                            <div class="shipping-price">Rp 0</div>
                            <div class="shipping-description">Affordable delivery within 1-3 hour.</div>
                        </div>
                    </label>
                </div>
            </div>

            <div class="payment-methods">
                <h3>Payment Method</h3>
                <div class="payment-option">
                    <input type="radio" name="payment" id="cash" value="cash">
                    <label for="cash">
                        <div class="payment-details">
                            <div class="payment-name">Cash</div>
                            <div class="payment-description">Pay with cash upon delivery.</div>
                        </div>
                    </label>
                </div>

                <div class="payment-option">
                    <input type="radio" name="payment" id="gopay" value="gopay" <?php echo isset($_SESSION['payment_method']) && $_SESSION['payment_method'] === 'gopay' ? 'checked' : ''; ?>>
                    <label for="gopay">
                        <div class="payment-details">
                            <div class="payment-name">Gopay</div>
                            <div class="payment-description">Pay using Gopay e-wallet.</div>
                        </div>
                    </label>

                </div>
            </div>
            <!-- Pop-up for Gopay -->
            <div class="popup-overlay" id="popup-overlay"></div>
            <div class="popup" id="gopay-popup">
                <h3>Link Gopay Account</h3>
                <p>Please enter your phone number to link your Gopay account:</p>
                <input type="text" id="gopay-phone" placeholder="Enter your phone number">
                <div class="buttons">
                    <button id="cancel-btn">Cancel</button>
                    <button id="link-btn">OK</button>
                </div>
            </div>

            <script>
                const gopayRadio = document.getElementById('gopay');
                const popup = document.getElementById('gopay-popup');
                const overlay = document.getElementById('popup-overlay');
                const cancelBtn = document.getElementById('cancel-btn');
                const linkBtn = document.getElementById('link-btn');
                // Show pop-up when Gopay is selected
                gopayRadio.addEventListener('change', () => {
                    if (gopayRadio.checked) {
                        overlay.style.display = 'block';
                        popup.style.display = 'block';
                    }
                });

                // Close pop-up when Cancel is clicked
                cancelBtn.addEventListener('click', () => {
                    overlay.style.display = 'none';
                    popup.style.display = 'none';
                });

                // Handle OK button click
                linkBtn.addEventListener('click', () => {
                    const phone = document.getElementById('gopay-phone').value;
                    if (!phone) {
                        alert('Please enter your phone number.');
                        return;
                    }
                    // Redirect to Gopay page with phone and balance details
                    window.location.href = `gopay.php?phone=${encodeURIComponent(phone)}&balance=0`;
                });
            </script>


            <h1>Shipping Information</h1>

            <?php if (isset($error)): ?>
                <p style="color: red;"><?= $error ?></p>
            <?php endif; ?>

            <h2>Customer Information</h2>
            <p>First Name: <?= htmlspecialchars($firstName ?? '') ?></p>
            <p>Last Name: <?= htmlspecialchars($lastName ?? '') ?></p>
            <p>Email: <?= htmlspecialchars($email ?? '') ?></p>
            <p>Phone: <?= htmlspecialchars($phone ?? '') ?></p>
            <p>Address: <?= htmlspecialchars($address ?? '') ?></p>

        </div>
        <div class="right-column">
            <h2>Order Summary</h2>

            <!-- Display Cart Items -->
            <div class="order-items">
                <?php foreach ($cart_items as $item): ?>
                    <div class="order-item">
                        <img src="../admin/<?= htmlspecialchars($item['image_path']) ?>"
                            alt="<?= htmlspecialchars($item['name']) ?>"
                            class="product-image">
                        <div class="product-details">
                            <h4><?= htmlspecialchars($item['name']) ?></h4>
                            <div class="product-price-and-quantity">
                                <p>Rp <?= number_format($item['price'], 0, ',', '.') ?></p>
                                <p>Quantity: <?= htmlspecialchars($item['quantity']) ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="summary-item" id="shipping-method">
                <p>Shipping Method:</p>
                <span>Not Selected</span>
            </div>

            <div class="summary-item" id="payment-method">
                <p>Payment Method:</p>
                <span>Not Selected</span>
            </div>

            <div class="summary-item" id="discount">
                <p>Discount (5%):</p>
                <span>Rp 0</span>
            </div>
            <!-- Phone Number Input Field -->
            <div class="summary-item" id="discount">
                <label for="phone">Nomor Telepon:</label>
                <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($phone ?? ''); ?>" required>
            </div>

            <h4 id="total">Total: Rp <span id="total"><?php echo $totalPrice; ?></span></h4>

            <!-- Checkout Button -->

            <form action="checkout.php" method="post">
                <input type="hidden" name="first_name" value="<?php echo $firstName; ?>">
                <input type="hidden" name="last_name" value="<?php echo $lastName; ?>">
                <input type="hidden" name="email" value="<?php echo $email; ?>">
                <input type="hidden" name="phone" value="<?php echo $phone; ?>">
                <input type="hidden" name="address" value="<?php echo $address; ?>">

                <!-- Loop through cart items and add hidden fields for each item -->
                <?php foreach ($cart_items as $item): ?>
                    <input type="hidden" name="cart_items[<?php echo $item['id']; ?>][product_id]" value="<?php echo $item['id']; ?>">
                    <input type="hidden" name="cart_items[<?php echo $item['id']; ?>][quantity]" value="<?php echo $item['quantity']; ?>">
                <?php endforeach; ?>

                <!-- Hidden fields for shipping and payment methods -->
                <input type="hidden" name="shipping_method" id="hidden_shipping_method" value="">
                <input type="hidden" name="payment_method" id="hidden_payment_method" value="">
                <!-- Hidden field for total price -->
                <input type="hidden" name="total_price" value="<?php echo $totalPrice; ?>">

                <button class="submit-btn" type="submit" name="checkout">Checkout</button>
            </form>





        </div>

    </div>
    <script>
    function updateOrderSummary() {
    // Ambil metode pengiriman yang dipilih
    const selectedShipping = document.querySelector('[name="shipping"]:checked');
    const shippingPrice = selectedShipping ? parseInt(selectedShipping.getAttribute('data-price')) : 0;
    const shippingMethodName = selectedShipping ? selectedShipping.parentElement.querySelector('.shipping-name').textContent : 'Not Selected';

    // Ambil subtotal dan diskon
    const subtotal = <?= $subtotal ?>; // Ambil subtotal dari PHP
    const discount = 0.05; // 5% diskon
    const subtotalAfterDiscount = subtotal - (subtotal * discount);

    // Total setelah diskon dan biaya pengiriman
    const total = subtotalAfterDiscount + shippingPrice;

    // Update elemen shipping-method
    document.getElementById('shipping-method').innerHTML = `<p>Shipping Method:</p><span>${shippingMethodName}</span>`;

    // Update metode pembayaran
    const selectedPayment = document.querySelector('[name="payment"]:checked');
    const paymentMethodName = selectedPayment ? selectedPayment.parentElement.querySelector('.payment-name').textContent : 'Not Selected';
    document.getElementById('payment-method').innerHTML = `<p>Payment Method:</p><span>${paymentMethodName}</span>`;

    // Update discount dan total
    document.getElementById('discount').innerHTML = `<p>Discount (5%):</p><span>Rp ${new Intl.NumberFormat().format(subtotal * discount)}</span>`;
    document.getElementById('total').innerHTML = `Total: Rp <span id="total">${new Intl.NumberFormat().format(total)}</span>`;

    // Update hidden fields untuk checkout
    document.getElementById('hidden_shipping_method').value = selectedShipping ? selectedShipping.value : 'Not Selected';
    document.getElementById('hidden_payment_method').value = selectedPayment ? selectedPayment.value : 'Not Selected';
    document.getElementById('hidden_total_price').value = total; // Update total_price
}

// Update harga total dan data lainnya ketika pilihan shipping dan payment berubah
document.querySelectorAll('[name="shipping"]').forEach(function(radio) {
    radio.addEventListener('change', updateOrderSummary);
});
document.querySelectorAll('[name="payment"]').forEach(function(radio) {
    radio.addEventListener('change', updateOrderSummary);
});

// Panggil fungsi pertama kali untuk inisialisasi
updateOrderSummary();
// Simpan data produk di localStorage setelah pengguna memilih produk
localStorage.setItem('cart_items', JSON.stringify(cartItems));

// Ambil data produk dari localStorage
const cartItemsFromStorage = JSON.parse(localStorage.getItem('cart_items'));

// Jika ada data produk yang tersimpan, tampilkan di halaman
if (cartItemsFromStorage) {
    // Gunakan data produk untuk menampilkan produk di halaman
}

</script>

    <script src="shipping.js"></script>
    <footer>
        <div class="footer-container">
            <div class="logo-section">
                <img src="alfagift.png" alt="Logo" class="logo">
            </div>
            <div class="menu-section">
                <div class="menu-column">
                    <h4>First Menu</h4>
                    <ul>
                        <li>Features</li>
                        <li>Enterprise</li>
                        <li>Security</li>
                        <li>Customer Stories</li>
                        <li>Pricing</li>
                        <li>Demo</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Second Menu</h4>
                    <ul>
                        <li>Engineering</li>
                        <li>Financial Services</li>
                        <li>Sales</li>
                        <li>IT</li>
                        <li>Customer Support</li>
                        <li>Human Resources</li>
                        <li>Media</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Third Menu</h4>
                    <ul>
                        <li>Tips</li>
                        <li>Blog</li>
                        <li>Event</li>
                        <li>Certified Program</li>
                        <li>Help Center</li>
                        <li>API</li>
                        <li>Download Template</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Fourth Menu</h4>
                    <ul>
                        <li>About Us</li>
                        <li>Leadership</li>
                        <li>News</li>
                        <li>Media Kit</li>
                        <li>Career</li>
                        <li>Documentation</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Alfagift © Copyright 2020, Inc. All rights reserved</p>
            <div class="social-media">
                <span>FB</span>
                <span>TW</span>
                <span>LN</span>
                <span>IG</span>
                <span>GH</span>
            </div>
        </div>
    </footer>

</body>

</html>