<?php
$host = 'localhost';      // atau IP server database jika berbeda
$user = 'root';           // username untuk database
$password = '';           // password untuk database
$dbname = 'alfagift';     // nama database yang digunakan
$conn = new mysqli($host, $user, $password, $dbname);
// Membuat koneksi
$connection = new mysqli($host, $user, $password, $dbname);

// Memeriksa koneksi
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

session_start();
if (!isset($_SESSION['user_email'])) {
    // Redirect ke halaman login jika belum login
    header("Location: sign in.php");
    exit;
}
// Debug untuk melihat data POST dan GET


// Ambil data produk dari URL query string
$productId = isset($_GET['id']) ? $_GET['id'] : '';
$productName = isset($_GET['name']) ? $_GET['name'] : '';
$productPrice = isset($_GET['price']) ? $_GET['price'] : '';
$productImage = isset($_GET['image']) ? $_GET['image'] : '';
$productQty = isset($_GET['qty']) ? $_GET['qty'] : 1;

// Tentukan produk yang akan ditampilkan di cart
$products = [
    [
        'id' => $productId,
        'name' => urldecode($productName),
        'price' => $productPrice,
        'image' => urldecode($productImage),
        'qty' => $productQty,
    ]
];
$totalItems = 0;

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Query untuk menghitung jumlah total item di keranjang
    $stmt = $conn->prepare("SELECT COUNT(DISTINCT product_id) AS total FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result) {
        $row = $result->fetch_assoc();
        $totalItems = isset($row['total']) ? (int)$row['total'] : 0;
    } else {
        $totalItems = 0;
    }

    $stmt->close();
}



// Inisialisasi variabel
$cart_items = [];
$subtotal = 0;

// Tangkap data dari POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cart_data'])) {
    $cart_items = json_decode($_POST['cart_data'], true);

    // Hitung subtotal
    foreach ($cart_items as $item) {
        $subtotal += $item['price'] * (isset($item['quantity']) ? $item['quantity'] : 0);
    }
}

if (isset($_POST['cart_data'])) {
    $_SESSION['cart_items'] = json_decode($_POST['cart_data'], true);
    $_SESSION['subtotal'] = $_POST['subtotal']; // Kirim subtotal
}
// Ambil data keranjang dan subtotal dari session
// Terima data dari form
$cart_data = isset($_POST['cart_data']) ? json_decode($_POST['cart_data'], true) : [];
$subtotal = isset($_POST['subtotal']) ? $_POST['subtotal'] : 0;

// Jika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = $_POST['first_name'] ?? '';
    $lastName = $_POST['last_name'] ?? '';
    $userId = $_POST['user_id'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $address = $_POST['address'] ?? '';

    if (isset($cart_data) && !empty($cart_data)) {
        $_SESSION['cart_items'] = $cart_data;
        $_SESSION['subtotal'] = $subtotal;
    }

    // Validasi form
    if (!$firstName || !$lastName || !$userId || !$phone || !$address) {
        $error = 'Please fill in all the required fields.';
    } else {
        // Simpan data customer di SESSION
        $_SESSION['customer_info'] = [
            'first_name' => $firstName,
            'last_name' => $lastName,
            'user_id' => $userId,
            'phone' => $phone,
            'address' => $address
        ];
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product - Alfagift</title>
    <link rel="stylesheet" href="customer.css">
</head>

<body>
    <script>
        function validateForm() {
            const firstName = document.getElementById('first-name').value.trim();
            const lastName = document.getElementById('last-name').value.trim();
            const userId = document.getElementById('user-id').value.trim();
            const phone = document.getElementById('phone').value.trim();
            const address = document.getElementById('address').value.trim();

            if (!firstName || !lastName || !userId || !phone || !address) {
                alert('Please fill in all the required fields.');
                return false;
            }
            return true;
        }
    </script>
    <!-- Header -->
    <header>
        <div class="top-bar">
            <div class="social-media">
                <a href="#" class='fb'><img src="faceb.png" alt="Facebook"></a>
                <a href="#"><img src="twit.png" alt="Twitter"></a>
                <a href="#"><img src="youtube.png" alt="YouTube"></a>
                <a href="#"><img src="instag.png" alt="Instagram"></a>
            </div>
            <div class="language">
                <span>Order tracking</span>
                <span>Help</span>
                <div class="dropdown">
                    <img src="US.png" alt="US Flag" class="flag">
                    <select class='bhs'>
                        <option>English (US)</option>
                        <option>Indonesia</option>
                    </select>
                </div>
            </div>

        </div>
        <div class="main-header">

            <img src="alfagift.png" alt="Alfagift Logo" class="logo">
            <div class="search-bar">

                <input type="text" placeholder="Search something...">
                <select>
                    <option class='opsi'>All Categories</option>
                </select>
                <button class='search'><img src="Search.png" alt="Search Icon"></button>

            </div>
            <nav>
                <a href="cart.php" class='cart'>
                    <img src="cart.png" alt="Cart">
                    <!-- Menampilkan badge jumlah item -->
                    <span class="badge"><?php echo $totalItems; ?></span>
                </a>
                <a href="#" class='cart'><img src="love.png" alt="Wishlist"></a>
                <a href="#" class="account-section">
                    <img src="account.png" alt="Account" class='account'>
                    <div>
                        <?php if (isset($_SESSION['user_email'])): ?>
                            <span class="account-text"><?= htmlspecialchars($_SESSION['user_email']) ?></span>
                        <?php else: ?>
                            <span class="join-text">Join Alfagift</span>
                            <span class="account-text">My Account</span>
                        <?php endif; ?>
                    </div>
                </a>
            </nav>

        </div>
    </header>
    <div class="content">
        <!-- Title Section -->
        <div class="title-section">
            <div class="title-text">
                <h1>Customer Information</h1>
                <p>Fill this form to know who you are. The lovely customer we care about it</p>
            </div>
            <a href="shop.php" class="back-button">Back to shopping</a>
        </div>

        <!-- Breadcrumb Section -->
        <div class="breadcrumb">
            <div class="breadcrumb-item-container">
                <span class="breadcrumb-number active">1</span>
                <span class="breadcrumb-item active">Cart</span>
            </div>
            <span class="breadcrumb-separator">→</span>

            <div class="breadcrumb-item-container">
                <span class="breadcrumb-number active">2</span>
                <span class="breadcrumb-item active">Customer Information</span>
            </div>
            <span class="breadcrumb-separator">→</span>

            <div class="breadcrumb-item-container">
                <span class="breadcrumb-number">3</span>
                <span class="breadcrumb-item">Shipping & payment</span>
            </div>
            <span class="breadcrumb-separator">→</span>

            <div class="breadcrumb-item-container">
                <span class="breadcrumb-number">4</span>
                <span class="breadcrumb-item">Review</span>
            </div>
        </div>

    </div>
    <div class="container">
        <!-- Left Column -->
        <div class="left-column">
            <form id="customerForm" action="shipping.php" method="POST" onsubmit="return validateForm()">
                <!-- Hidden fields untuk cart dan subtotal -->
                <input type="hidden" name="cart_data" value='<?= htmlspecialchars(json_encode($_SESSION['cart_items'])) ?>'>
                <input type="hidden" name="subtotal" value="<?= htmlspecialchars($_SESSION['subtotal']) ?>">

                <!-- Kirim data customer -->
                <input type="hidden" name="user_id" value="<?= htmlspecialchars($_SESSION['user_id']) ?>">
                <input type="hidden" name="first_name" value="<?= htmlspecialchars($_SESSION['customer_info']['first_name'] ?? '') ?>">
                <input type="hidden" name="last_name" value="<?= htmlspecialchars($_SESSION['customer_info']['last_name'] ?? '') ?>">
                <input type="hidden" name="phone" value="<?= htmlspecialchars($_SESSION['customer_info']['phone'] ?? '') ?>">
                <input type="hidden" name="address" value="<?= htmlspecialchars($_SESSION['customer_info']['address'] ?? '') ?>">

                <div class="form-row">
                    <div class="form-group">
                        <label for="first-name">First Name:</label>
                        <input type="text" id="first-name" name="first_name" value="<?= htmlspecialchars($_SESSION['customer_info']['first_name'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="last-name">Last Name:</label>
                        <input type="text" id="last-name" name="last_name" value="<?= htmlspecialchars($_SESSION['customer_info']['last_name'] ?? '') ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="email">Your Email:</label>
                        <input type="email" id="email" name="email" value="<?= htmlspecialchars($_SESSION['user_email'] ?? '') ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Phone Number:</label>
                        <input type="tel" id="phone" name="phone" value="<?= htmlspecialchars($_SESSION['customer_info']['phone'] ?? '') ?>" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="address">Address Details:</label>
                    <textarea id="address" name="address" rows="3" required><?= htmlspecialchars($_SESSION['customer_info']['address'] ?? '') ?></textarea>
                </div>

                <!-- Submit Button -->
                <button class="submit-btn" type="submit">Proceed to Shipping</button>
            </form>




            <button class="back-btn" onclick="location.href='cart.php'">Back to Cart</button>
        </div>


        <div class="right-column">
            <h2>Order Summary</h2>

            <!-- Display Cart Items -->
            <div class="order-items">
                <?php foreach ($cart_data as $item): ?>
                    <div class="order-item">
                        <img src="../admin/<?= htmlspecialchars($item['image_path']) ?>"
                            alt="<?= htmlspecialchars($item['name']) ?>"
                            class="product-image">
                        <div class="product-details">
                            <h4><?= htmlspecialchars($item['name']) ?></h4>
                            <div class="product-price-and-quantity">
                                <p>Rp <?= number_format($item['price'], 0, ',', '.') ?></p>
                                <p>Item Ordered: <?= htmlspecialchars($item['quantity']) ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Summary Section -->
            <div class="summary-item">
                <p>Subtotal:</p>
                <p>Rp <?= number_format($subtotal, 0, ',', '.') ?></p>
            </div>

        </div>


    </div>
    <script src="customer.js"></script>
    <footer>
        <div class="footer-container">
            <div class="logo-section">
                <img src="alfagift.png" alt="Logo" class="logo">
            </div>
            <div class="menu-section">
                <div class="menu-column">
                    <h4>First Menu</h4>
                    <ul>
                        <li>Features</li>
                        <li>Enterprise</li>
                        <li>Security</li>
                        <li>Customer Stories</li>
                        <li>Pricing</li>
                        <li>Demo</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Second Menu</h4>
                    <ul>
                        <li>Engineering</li>
                        <li>Financial Services</li>
                        <li>Sales</li>
                        <li>IT</li>
                        <li>Customer Support</li>
                        <li>Human Resources</li>
                        <li>Media</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Third Menu</h4>
                    <ul>
                        <li>Tips</li>
                        <li>Blog</li>
                        <li>Event</li>
                        <li>Certified Program</li>
                        <li>Help Center</li>
                        <li>API</li>
                        <li>Download Template</li>
                    </ul>
                </div>
                <div class="menu-column">
                    <h4>Fourth Menu</h4>
                    <ul>
                        <li>About Us</li>
                        <li>Leadership</li>
                        <li>News</li>
                        <li>Media Kit</li>
                        <li>Career</li>
                        <li>Documentation</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>Alfagift © Copyright 2020, Inc. All rights reserved</p>
            <div class="social-media">
                <span>FB</span>
                <span>TW</span>
                <span>LN</span>
                <span>IG</span>
                <span>GH</span>
            </div>
        </div>
    </footer>

</body>

</html>