thumbnails.forEach((thumbnail) => {
    thumbnail.addEventListener("click", function () {
        const newImageSrc = this.dataset.image; // Path gambar baru
        console.log("Mengubah gambar utama ke:", newImageSrc); // Debugging
        mainImage.src = newImageSrc;

        // Hapus dan tambahkan kelas aktif
        thumbnails.forEach((thumb) => thumb.classList.remove("active"));
        this.classList.add("active");
    });
});

// Menambahkan interaktivitas tombol
document.getElementById("buyNow").addEventListener("click", function () {
    alert("Thank you for purchasing!");
});

document.getElementById("addToCart").addEventListener("click", function () {
    alert("Product added to your cart!");
});
