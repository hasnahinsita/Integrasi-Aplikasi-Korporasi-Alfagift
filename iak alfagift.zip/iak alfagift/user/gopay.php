<?php
// Fetch the balance when the page loads
// Fetch the balance when the page loads
$phone = $_GET['phone'] ?? 'Tidak tersedia';
$conn = new mysqli('localhost', 'root', '', 'gopay');
$sql = "SELECT balance FROM saldo WHERE phone = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $phone);
$stmt->execute();
$stmt->bind_result($balance);
$stmt->fetch();
$conn->close();
session_start();



?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GoPay Clone</title>
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        /* General Styling */
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f0f4f7;
            /* Light background */
            color: #333;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Topbar Styling */
        .topbar {
            background-color: #00A6E3;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            width: 100%;
            position: absolute;
            top: 0;
            left: 0;
        }

        .topbar h1 {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
        }

        .topbar button {
            background-color: #007bbd;
            color: white;
            border: none;
            padding: 8px 12px;
            font-size: 14px;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .topbar button:hover {
            background-color: #005f8b;
        }

        /* Container Styling */
        .container {
            text-align: center;
            background: linear-gradient(135deg, #00A6E3, #007BB5);
            padding: 40px;
            border-radius: 100px;
            max-width: 1100px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
            width: 90%;
            height: 320px;
        }

        .container h1 {
            font-size: 36px;
            font-weight: bold;
            background: linear-gradient(135deg, #00A6E3, #00C853);
            border-radius: 50px;
        }

        .container p {
            font-size: 16px;
            margin: 10px 0;
            color: #fff;
        }

        .balance {
            font-size: 28px;
            font-weight: bold;
            color: #fff;
            margin-bottom: 20px;
        }

        .phone-number {
            font-size: 18px;
            margin-bottom: 20px;
            color: #fff;
        }

        .buttons button {
            background: linear-gradient(135deg, #00C853, #00A6E3);
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s;
            margin-right: 10px;
        }

        .buttons button:hover {
            background: linear-gradient(135deg, #00A6E3, #00C853);
        }

        /* Footer Styling */
        .footer {
            background-color: #f5f5f5;
            text-align: center;
            padding: 15px 10px;
            font-size: 14px;
            color: #666;
            position: absolute;
            bottom: 0;
            width: 100%;
        }

        .footer a {
            color: #00a6e3;
            text-decoration: none;
            font-weight: bold;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        /* Icon Section Styling */
        .icon-container {
            display: flex;
            justify-content: center;
            margin-top: 20px;
            padding: 10px 0;
            gap: 40px;
            margin-bottom: 30px;
        }

        .icon-container i {
            font-size: 36px;
            color: #fff;
            cursor: pointer;
            transition: transform 0.3s;
        }

        .icon-container i:hover {
            transform: scale(1.2);
        }

        /* Modal Styling */
        /* Modal Styling */
        .modal {
            display: none;
            /* Hidden by default */
            position: fixed;
            z-index: 1;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4);
            /* Semi-transparent background */
            padding-top: 60px;
            justify-content: center;
            align-items: center;
            display: flex;
        }

        /* Modal Content */
        .modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            width: 80%;
            max-width: 400px;
            /* Ensure the modal is centered */
            margin: auto;
            /* This helps in case flexbox fails */
        }


        .modal-content h2 {
            margin: 0;
            font-size: 24px;
            text-align: center;
            color: #00A6E3;
        }

        .modal-content input {
            padding: 10px;
            margin: 10px 0;
            width: 100%;
            border: 1px solid #ddd;
            border-radius: 6px;
        }

        .modal-content button {
            background-color: #00A6E3;
            color: white;
            padding: 10px;
            border: none;
            cursor: pointer;
            border-radius: 6px;
            width: 100%;
            font-size: 16px;
            margin-bottom: 5px;
        }

        .modal-content button:hover {
            background-color: #007bbd;
        }
    </style>
</head>

<body>

    <!-- Topbar -->
    <div class="topbar">
        <h1>GoPay</h1>
        <button onclick="alert('Fitur bantuan belum tersedia')">Bantuan</button>
    </div>

    <!-- Container -->
    <div class="container">
        <h1>Bayar apa aja pakai GoPay</h1>
        <div class="phone-number" id="gopay-phone">Nomor GoPay: -</div>
        <div class="balance" id="gopay-balance">Rp <?php echo number_format($balance, 2, ',', '.'); ?></div>


        <!-- Icons Section -->
        <div class="icon-container">
            <i class="fas fa-qrcode"></i>
            <i class="fas fa-shopping-cart"></i>
            <i class="fas fa-plus-circle" onclick="openModal()"></i>
            <i class="fas fa-exchange-alt"></i>
        </div>

        <div class="buttons">
            <button onclick="showPopup()">Isi Saldo</button>

            <button onclick="window.location.href='shipping.php?phone=' + encodeURIComponent(phone)">Kembali</button>

        </div>
    </div>

    <!-- Footer -->
    <div class="footer">
        © 2024 GoPay. Semua Hak Dilindungi. | <a href="#">Kebijakan Privasi</a> | <a href="#">Syarat & Ketentuan</a>
    </div>
    </div>
    <!-- Modal for Isi Saldo -->
    <!-- Modal for Isi Saldo -->
    <div id="popup" class="modal" style="display: none;">
        <div class="modal-content">
            <h2>Isi Saldo</h2>
            <input type="number" id="saldo-amount" placeholder="Jumlah saldo" min="1" required>
            <button onclick="addSaldo()">OK</button>
            <button onclick="closePopup()">Batal</button>
        </div>
    </div>



    <!-- Script to Populate Data and Modal -->
    <script>
        // Function to show the popup
        function showPopup() {
            document.getElementById('popup').style.display = 'block';
        }

        // Function to close the popup
        function closePopup() {
            document.getElementById('popup').style.display = 'none';
        }

        // Get phone and balance from URL params
        const urlParams = new URLSearchParams(window.location.search);
        const phone = urlParams.get('phone') || 'Tidak tersedia';
        const balance = urlParams.get('balance') || '0';

        // Display phone number and balance
        document.getElementById('gopay-phone').innerText = `Nomor GoPay: ${phone}`;
        document.getElementById('gopay-balance').innerText = `Rp ${parseInt(balance).toLocaleString()}`;

        // Function to open the modal and set the phone number
        function openModal() {
            document.getElementById('popup').style.display = 'block';

            document.getElementById('phone-input').value = phone; // Set the phone number in the hidden input
        }

        // Handle form submission with AJAX
        document.getElementById('saldo-form').addEventListener('submit', function(e) {
            e.preventDefault(); // Prevent form from submitting normally

            // Prepare form data
            const saldoAmount = document.getElementById('saldo-amount').value;
            const phone = document.getElementById('phone-input').value;

            // Create a FormData object to send the form data via AJAX
            const formData = new FormData();
            formData.append('saldo_amount', saldoAmount);
            formData.append('phone', phone);

            // Send AJAX request to update saldo
            fetch('update_balance.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    // Check if the update was successful
                    if (data.success) {
                        // Update the balance in the UI
                        const newBalance = parseFloat(data.new_balance);
                        document.getElementById('gopay-balance').innerText = `Rp ${newBalance.toLocaleString()}`;
                        alert('Saldo berhasil diupdate');
                        closeModal(); // Close the modal after successful update
                    } else {
                        alert('Gagal mengupdate saldo');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Terjadi kesalahan saat mengupdate saldo');
                });
        });

        // Function to close the modal
        function closeModal() {
            document.getElementById('myModal').style.display = 'none';
        }

        // Function to show the popup
        function showPopup() {
            document.getElementById('popup').style.display = 'block';
        }

        // Function to close the popup
        function closePopup() {
            document.getElementById('popup').style.display = 'none';
        }

        // Function to handle saldo addition using AJAX
        // Function to handle saldo addition using AJAX
        function addSaldo() {
            const saldoAmount = document.getElementById('saldo-amount').value;
            const phone = '<?php echo $_GET['phone']; ?>'; // Get phone number from URL (or dynamically set it)

            if (saldoAmount && !isNaN(saldoAmount) && saldoAmount > 0) {
                // AJAX request to update balance
                const xhr = new XMLHttpRequest();
                xhr.open('POST', 'update_balance.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onreadystatechange = function() {
                    if (xhr.readyState === 4 && xhr.status === 200) {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            // Update the displayed saldo on the page without refreshing
                            document.getElementById('gopay-balance').innerText = 'Rp ' + response.new_balance.toLocaleString();
                            closePopup(); // Close the popup after successful update
                        } else {
                            alert(response.message);
                        }
                    }
                };
                xhr.send('phone=' + encodeURIComponent(phone) + '&saldo_amount=' + encodeURIComponent(saldoAmount));
            } else {
                alert('Jumlah saldo tidak valid');
            }
        }
    </script>

</body>

</html>